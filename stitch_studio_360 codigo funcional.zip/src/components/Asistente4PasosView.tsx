import React, { useState } from 'react';
import { BrandProfile, ScreenView } from '../types';

interface Asistente4PasosViewProps {
  activeBrand: BrandProfile;
  onChangeView: (view: ScreenView) => void;
  onShowToast: (msg: string) => void;
}

export const Asistente4PasosView: React.FC<Asistente4PasosViewProps> = ({
  activeBrand,
  onChangeView,
  onShowToast
}) => {
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [fastMode, setFastMode] = useState<boolean>(true);
  const [selectedProduct, setSelectedProduct] = useState<string>('croissant');
  const [selectedAngle, setSelectedAngle] = useState<string>('antojo');
  const [selectedChannels, setSelectedChannels] = useState<string[]>(['instagram', 'tiktok', 'whatsapp']);
  const [selectedCopyVariant, setSelectedCopyVariant] = useState<number>(1);
  const [isDeploying, setIsDeploying] = useState<boolean>(false);

  const products = [
    { id: 'croissant', name: 'Croissant Artesanal de Mantequilla', price: '$3.50', tag: 'Top Ventas', icon: '🥐' },
    { id: 'tarta', name: 'Tarta de Frutos Rojos y Crema', price: '$18.00', tag: 'Especial', icon: '🍓' },
    { id: 'masa-madre', name: 'Pan Rústico de Masa Madre 48h', price: '$5.00', tag: 'Artesanal', icon: '🥖' },
    { id: 'combo', name: 'Combo Desayuno Dulce Placer 2x1', price: '$8.50', tag: 'Promo Flash', icon: '☕' }
  ];

  const angles = [
    {
      id: 'antojo',
      title: 'Antojo Irresistible & ASMR',
      description: 'Hojaldre crujiente, sonido del primer corte, mantequilla dorada y textura caliente.',
      badge: 'Retención 88%'
    },
    {
      id: 'amor',
      title: 'Día del Amor y la Amistad',
      description: 'Regalos dulces para compartir, detalles artesanales que enamoran a primera vista.',
      badge: 'Tendencia Q1'
    },
    {
      id: 'escasez',
      title: 'Escasez Flash (FOMO)',
      description: 'Solo 20 cajas disponibles hoy. Llamado urgente a ordenar por WhatsApp antes de agotar.',
      badge: 'Conversión Alta'
    },
    {
      id: 'artesanal',
      title: 'Detrás de Escena & Proceso',
      description: 'Fermentación lenta de 48 horas, masa madre viva y pasión del maestro panadero.',
      badge: 'Autoridad de Marca'
    }
  ];

  const copyOptions = [
    {
      id: 1,
      name: 'Variante 1: Enfoque Sensorial & Antojo',
      badge: 'TikTok / Reels',
      text: '🥐 72 capas de puro hojaldre crujiente y mantequilla dorada. Recién salidos del horno en Panadería Dulce Placer. ¿Con qué lo acompañarías hoy: café latte o chocolate caliente? 👇 Pide el tuyo antes de que se acaben.'
    },
    {
      id: 2,
      name: 'Variante 2: Emotiva & Amor Artesanal',
      badge: 'Instagram Feed',
      text: '✨ El amor se hornea despacio. Porque no hay mejor detalle para esa persona especial que el aroma a pan caliente recién hecho con masa madre. Reserva tu caja de San Valentín con dedicatoria personalizada en el enlace de la bio.'
    },
    {
      id: 3,
      name: 'Variante 3: Escasez Flash & Cierre WhatsApp',
      badge: 'WhatsApp VIP',
      text: '🔥 ¡ALERTA FLASH! Solo horneamos 30 croissants especiales hoy. Quedan exactamente 8 cajas disponibles. Responde este mensaje con la palabra "QUIERO" para apartar la tuya con 2x1.'
    }
  ];

  const toggleChannel = (channel: string) => {
    setSelectedChannels((prev) =>
      prev.includes(channel) ? prev.filter((c) => c !== channel) : [...prev, channel]
    );
  };

  const handleFinishWizard = () => {
    setIsDeploying(true);
    setTimeout(() => {
      setIsDeploying(false);
      onShowToast('✓ ¡Campaña sincronizada y disparada en Instagram, TikTok y WhatsApp vía n8n!');
      onChangeView('calendario');
    }, 1500);
  };

  return (
    <div className="flex flex-col w-full gap-4 pb-28 animate-in fade-in duration-300">
      {/* Wizard Header con Stepper */}
      <section className="bg-[#181c24] p-4 rounded-2xl border border-white/5 space-y-3 shadow-md">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-[10px] font-mono text-[#4edea3] uppercase tracking-wider font-bold">
              Asistente Guiado de Campaña
            </span>
            <h2 className="font-display text-sm font-bold text-white">
              Paso {currentStep} de 4: {currentStep === 1 ? 'Marca & Modo' : currentStep === 2 ? 'Enfoque Creativo' : currentStep === 3 ? 'Canales & Formatos' : 'Copys IA & Despacho'}
            </h2>
          </div>
          <span className="text-xs font-mono font-bold text-slate-400 bg-[#0a0e16] px-2.5 py-1 rounded-full border border-white/5">
            {currentStep * 25}%
          </span>
        </div>

        {/* Segmented Progress Bar */}
        <div className="grid grid-cols-4 gap-1">
          {[1, 2, 3, 4].map((step) => (
            <div
              key={step}
              className={`h-1.5 rounded-full transition-all duration-300 ${
                step <= currentStep ? 'bg-[#4edea3]' : 'bg-[#262a33]'
              }`}
            ></div>
          ))}
        </div>
      </section>

      {/* PASO 1: Marca & Modo */}
      {currentStep === 1 && (
        <section className="space-y-3 animate-in fade-in">
          {/* Fast Track Mode Switch */}
          <div className="bg-gradient-to-r from-emerald-500/10 to-purple-500/10 p-3 rounded-2xl border border-emerald-500/30 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-7 h-7 rounded-lg bg-emerald-500/20 text-[#4edea3] flex items-center justify-center">
                ⚡
              </span>
              <div>
                <span className="text-xs font-bold text-white block">Modo Rápido 1-Clic</span>
                <span className="text-[10px] text-slate-400">Auto-calibra canales y copys con IA</span>
              </div>
            </div>
            <button
              onClick={() => {
                setFastMode(!fastMode);
                onShowToast(fastMode ? 'Modo personalizado' : 'Modo rápido activado');
              }}
              className={`w-11 h-6 rounded-full p-1 transition-all ${fastMode ? 'bg-[#4edea3]' : 'bg-slate-700'}`}
            >
              <div className={`w-4 h-4 rounded-full bg-black transition-all ${fastMode ? 'translate-x-5' : 'translate-x-0'}`}></div>
            </button>
          </div>

          {/* Product Picker */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-white flex items-center justify-between">
              <span>Selecciona Producto del Inventario:</span>
              <span className="text-[10px] text-[#4edea3] font-mono">{activeBrand.name}</span>
            </label>

            <div className="grid grid-cols-2 gap-2">
              {products.map((p) => (
                <button
                  key={p.id}
                  onClick={() => setSelectedProduct(p.id)}
                  className={`p-3 rounded-2xl text-left border transition-all flex flex-col justify-between min-h-[95px] ${
                    selectedProduct === p.id
                      ? 'bg-emerald-500/15 border-[#4edea3] shadow-md shadow-emerald-500/10'
                      : 'bg-[#181c24] border-white/5 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xl">{p.icon}</span>
                    <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-[#262a33] text-slate-300">
                      {p.tag}
                    </span>
                  </div>
                  <div className="mt-2">
                    <span className="text-xs font-bold text-white block line-clamp-1">{p.name}</span>
                    <span className="text-xs font-mono text-[#4edea3] font-bold">{p.price}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* PASO 2: Enfoque Creativo & Ángulo */}
      {currentStep === 2 && (
        <section className="space-y-2.5 animate-in fade-in">
          <span className="text-xs font-bold text-white block">
            Elige el Ángulo Psicológico de la Campaña:
          </span>

          <div className="space-y-2">
            {angles.map((angle) => (
              <div
                key={angle.id}
                onClick={() => setSelectedAngle(angle.id)}
                className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-start justify-between gap-2 ${
                  selectedAngle === angle.id
                    ? 'bg-purple-600/15 border-purple-500 shadow-md'
                    : 'bg-[#181c24] border-white/5 hover:border-slate-700'
                }`}
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white">{angle.title}</span>
                    <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300">
                      {angle.badge}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">{angle.description}</p>
                </div>
                {selectedAngle === angle.id && (
                  <span className="material-symbols-outlined text-purple-400 text-[18px]">check_circle</span>
                )}
              </div>
            ))}
          </div>
        </section>
      )}

      {/* PASO 3: Canales & Formatos */}
      {currentStep === 3 && (
        <section className="space-y-3 animate-in fade-in">
          <span className="text-xs font-bold text-white block">
            Selecciona Canales de Distribución n8n:
          </span>

          <div className="space-y-2">
            <button
              onClick={() => toggleChannel('instagram')}
              className={`w-full p-3 rounded-2xl border flex items-center justify-between text-left transition-all ${
                selectedChannels.includes('instagram')
                  ? 'bg-pink-500/10 border-pink-500/40 text-white'
                  : 'bg-[#181c24] border-white/5 text-slate-400'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <span className="material-symbols-outlined text-pink-400 text-[20px]">photo_camera</span>
                <div>
                  <span className="text-xs font-bold block">Instagram Reels & Feed (1:1 + 9:16)</span>
                  <span className="text-[10px] text-slate-400">Estética visual y ganchos de video</span>
                </div>
              </div>
              <span className={`material-symbols-outlined text-[18px] ${selectedChannels.includes('instagram') ? 'text-pink-400' : 'text-slate-600'}`}>
                {selectedChannels.includes('instagram') ? 'check_box' : 'check_box_outline_blank'}
              </span>
            </button>

            <button
              onClick={() => toggleChannel('tiktok')}
              className={`w-full p-3 rounded-2xl border flex items-center justify-between text-left transition-all ${
                selectedChannels.includes('tiktok')
                  ? 'bg-cyan-500/10 border-cyan-500/40 text-white'
                  : 'bg-[#181c24] border-white/5 text-slate-400'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <span className="material-symbols-outlined text-cyan-400 text-[20px]">video_library</span>
                <div>
                  <span className="text-xs font-bold block">TikTok Orgánico (9:16)</span>
                  <span className="text-[10px] text-slate-400">Audio viral Cafe Parisien + gancho ASMR</span>
                </div>
              </div>
              <span className={`material-symbols-outlined text-[18px] ${selectedChannels.includes('tiktok') ? 'text-cyan-400' : 'text-slate-600'}`}>
                {selectedChannels.includes('tiktok') ? 'check_box' : 'check_box_outline_blank'}
              </span>
            </button>

            <button
              onClick={() => toggleChannel('whatsapp')}
              className={`w-full p-3 rounded-2xl border flex items-center justify-between text-left transition-all ${
                selectedChannels.includes('whatsapp')
                  ? 'bg-emerald-500/10 border-emerald-500/40 text-white'
                  : 'bg-[#181c24] border-white/5 text-slate-400'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <span className="material-symbols-outlined text-emerald-400 text-[20px]">chat</span>
                <div>
                  <span className="text-xs font-bold block">Canal VIP WhatsApp (640 Miembros)</span>
                  <span className="text-[10px] text-slate-400">Mensaje de escasez con checkout directo</span>
                </div>
              </div>
              <span className={`material-symbols-outlined text-[18px] ${selectedChannels.includes('whatsapp') ? 'text-emerald-400' : 'text-slate-600'}`}>
                {selectedChannels.includes('whatsapp') ? 'check_box' : 'check_box_outline_blank'}
              </span>
            </button>
          </div>
        </section>
      )}

      {/* PASO 4: Copys IA & Previsualización */}
      {currentStep === 4 && (
        <section className="space-y-3 animate-in fade-in">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-white">Copys Calibrados por IA:</span>
            <span className="text-[10px] text-[#4edea3] font-mono">3 Opciones Listas</span>
          </div>

          <div className="space-y-2">
            {copyOptions.map((opt) => (
              <div
                key={opt.id}
                onClick={() => setSelectedCopyVariant(opt.id)}
                className={`p-3 rounded-2xl border transition-all cursor-pointer space-y-1.5 ${
                  selectedCopyVariant === opt.id
                    ? 'bg-[#181c24] border-emerald-500 shadow-md'
                    : 'bg-[#12161e] border-white/5 opacity-80 hover:opacity-100'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white">{opt.name}</span>
                  <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-emerald-500/20 text-[#4edea3]">
                    {opt.badge}
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">{opt.text}</p>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Footer Navigation Buttons */}
      <div className="flex items-center justify-between gap-2 pt-2">
        {currentStep > 1 ? (
          <button
            onClick={() => setCurrentStep((prev) => prev - 1)}
            className="py-2.5 px-4 rounded-xl bg-[#262a33] text-slate-200 text-xs font-semibold hover:bg-slate-700 transition-colors"
          >
            ← Volver
          </button>
        ) : (
          <div></div>
        )}

        {currentStep < 4 ? (
          <button
            onClick={() => setCurrentStep((prev) => prev + 1)}
            className="flex-1 max-w-[200px] ml-auto py-2.5 px-4 rounded-xl bg-[#4edea3] text-black text-xs font-bold font-display flex items-center justify-center gap-1 shadow-md active:scale-95 transition-all"
          >
            <span>Siguiente Paso</span>
            <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
          </button>
        ) : (
          <button
            onClick={handleFinishWizard}
            disabled={isDeploying}
            className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-400 via-teal-400 to-[#4edea3] text-black font-bold font-display text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-500/20 active:scale-95 transition-all"
          >
            {isDeploying ? (
              <>
                <span className="material-symbols-outlined text-[16px] animate-spin">refresh</span>
                <span>Disparando con n8n...</span>
              </>
            ) : (
              <>
                <span className="material-symbols-outlined text-[18px]">rocket_launch</span>
                <span>Aprobar y Disparar con n8n</span>
              </>
            )}
          </button>
        )}
      </div>
    </div>
  );
};
