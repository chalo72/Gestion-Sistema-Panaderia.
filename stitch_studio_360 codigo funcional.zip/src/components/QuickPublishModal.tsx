import React, { useState } from 'react';

interface QuickPublishModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (msg: string) => void;
  activeBrandName: string;
}

export const QuickPublishModal: React.FC<QuickPublishModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  activeBrandName
}) => {
  const [selectedChannel, setSelectedChannel] = useState<'reels' | 'tiktok' | 'whatsapp'>('reels');
  const [copyText, setCopyText] = useState('🥐 Recién horneados: Croissants de Mantequilla Dorada. ¡Solo 30 unidades hoy en tienda! Reserva el tuyo en el link.');
  const [isDeploying, setIsDeploying] = useState(false);

  if (!isOpen) return null;

  const handleGenerateAiCopy = () => {
    const samples = [
      '🔥 ¡Tanda recién salida! Pan rústico de masa madre con 48h de fermentación. Disponible ahora en Panadería Dulce Placer.',
      '🥐 Crujiente por fuera, esponjoso por dentro. Mira nuestro proceso de hojaldrado artesanal en vivo.',
      '✨ Edición limitada de hoy: Tartaletas de Frutos Rojos con crema diplomática. ¡Pide por WhatsApp antes de las 18:00!'
    ];
    setCopyText(samples[Math.floor(Math.random() * samples.length)]);
  };

  const handleDispatch = () => {
    setIsDeploying(true);
    setTimeout(() => {
      setIsDeploying(false);
      onClose();
      onSuccess(`✓ Despacho Flash 360° exitoso hacia ${selectedChannel === 'reels' ? 'Instagram Reels' : selectedChannel === 'tiktok' ? 'TikTok' : 'WhatsApp VIP'}`);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in">
      <div className="bg-[#0b101c]/95 border border-[#4edea3]/40 rounded-2xl p-5 shadow-2xl max-w-sm w-full text-slate-100 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
          <div className="flex items-center gap-2">
            <span className="w-7 h-7 rounded-lg bg-[#4edea3]/20 border border-[#4edea3]/40 flex items-center justify-center text-[#4edea3]">
              <span className="material-symbols-outlined text-[18px]">bolt</span>
            </span>
            <div>
              <h4 className="font-display font-bold text-sm text-white leading-tight">Publicación Flash 360°</h4>
              <p className="text-[10px] text-[#4edea3] font-mono">1-Tap Deploy • n8n Webhook</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <span className="material-symbols-outlined text-[18px]">close</span>
          </button>
        </div>

        {/* Target Channel Selector */}
        <div className="space-y-1.5">
          <label className="text-[11px] font-medium text-slate-300 flex items-center justify-between">
            <span>Canal de Destino:</span>
            <span className="text-[10px] text-slate-400">{activeBrandName}</span>
          </label>
          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => setSelectedChannel('reels')}
              className={`px-2 py-2 rounded-xl text-[11px] font-semibold flex flex-col items-center gap-1 transition-all ${
                selectedChannel === 'reels'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/50 shadow-sm'
                  : 'bg-[#111726] text-slate-400 border border-slate-800 hover:border-slate-700'
              }`}
            >
              <span className="material-symbols-outlined text-[16px] text-pink-400">photo_camera</span>
              <span>IG Reels</span>
            </button>
            <button
              type="button"
              onClick={() => setSelectedChannel('tiktok')}
              className={`px-2 py-2 rounded-xl text-[11px] font-semibold flex flex-col items-center gap-1 transition-all ${
                selectedChannel === 'tiktok'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 shadow-sm'
                  : 'bg-[#111726] text-slate-400 border border-slate-800 hover:border-slate-700'
              }`}
            >
              <span className="material-symbols-outlined text-[16px] text-cyan-400">video_library</span>
              <span>TikTok ASMR</span>
            </button>
            <button
              type="button"
              onClick={() => setSelectedChannel('whatsapp')}
              className={`px-2 py-2 rounded-xl text-[11px] font-semibold flex flex-col items-center gap-1 transition-all ${
                selectedChannel === 'whatsapp'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/50 shadow-sm'
                  : 'bg-[#111726] text-slate-400 border border-slate-800 hover:border-slate-700'
              }`}
            >
              <span className="material-symbols-outlined text-[16px] text-emerald-400">chat</span>
              <span>WhatsApp VIP</span>
            </button>
          </div>
        </div>

        {/* Copy preview & prompt input */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-slate-300 font-medium">Copy / Titular Flash:</span>
            <button
              type="button"
              onClick={handleGenerateAiCopy}
              className="text-[#4edea3] hover:text-emerald-300 text-[10px] flex items-center gap-1 font-semibold"
            >
              <span className="material-symbols-outlined text-[12px]">auto_awesome</span> Asistir con IA
            </button>
          </div>
          <textarea
            rows={2}
            value={copyText}
            onChange={(e) => setCopyText(e.target.value)}
            className="w-full bg-[#111726] border border-slate-700/80 rounded-xl p-2.5 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-[#4edea3] focus:ring-1 focus:ring-[#4edea3] resize-none transition-all"
          />
        </div>

        {/* Preset Fast Media Selector */}
        <div className="flex items-center justify-between text-[11px] bg-[#111726] p-2 rounded-xl border border-slate-800">
          <div className="flex items-center gap-2">
            <span className="w-7 h-7 rounded-lg bg-[#4edea3]/15 text-[#4edea3] flex items-center justify-center">
              <span className="material-symbols-outlined text-[16px]">image</span>
            </span>
            <div>
              <div className="text-slate-200 font-medium text-[11px]">croissant-golden-hour.mp4</div>
              <div className="text-slate-400 text-[9px]">Filtro Cinematic Gold • 9:16</div>
            </div>
          </div>
          <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/10 text-[#4edea3] font-mono">Listo</span>
        </div>

        {/* Dispatch Action Button */}
        <button
          onClick={handleDispatch}
          disabled={isDeploying}
          className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-400 via-teal-400 to-[#4edea3] hover:from-emerald-300 hover:to-teal-300 text-black font-display font-bold text-xs tracking-wide shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
        >
          {isDeploying ? (
            <>
              <span className="material-symbols-outlined text-[16px] animate-spin">refresh</span>
              <span>Sincronizando con n8n...</span>
            </>
          ) : (
            <>
              <span className="material-symbols-outlined text-[16px]">send</span>
              <span>Despachar Ahora con 1-Toque</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
