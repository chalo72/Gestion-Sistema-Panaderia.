import React, { useState } from 'react';
import { BrandProfile, ScreenView } from '../types';
import { CALENDAR_POSTS } from '../data';

interface CalendarioParrillaViewProps {
  activeBrand: BrandProfile;
  onChangeView: (view: ScreenView) => void;
  onShowToast: (msg: string) => void;
}

export const CalendarioParrillaView: React.FC<CalendarioParrillaViewProps> = ({
  activeBrand,
  onChangeView,
  onShowToast
}) => {
  const [activeTab, setActiveTab] = useState<'semanal' | 'canal' | 'embudo'>('semanal');
  const [selectedPillar, setSelectedPillar] = useState<'all' | 'marca' | 'interaccion' | 'comunidad' | 'conversion'>('all');
  const [syncSpin, setSyncSpin] = useState<boolean>(false);

  const filteredPosts = CALENDAR_POSTS.filter((post) => {
    if (selectedPillar === 'all') return true;
    if (selectedPillar === 'conversion' && post.pillarCategory === 'BOFU') return true;
    if (selectedPillar === 'interaccion' && post.pillarCategory === 'MOFU') return true;
    if (selectedPillar === 'marca' && post.pillarCategory === 'TOFU') return true;
    if (selectedPillar === 'comunidad' && post.pillarCategory === 'Comunidad') return true;
    return true;
  });

  const handleSyncN8n = () => {
    setSyncSpin(true);
    setTimeout(() => {
      setSyncSpin(false);
      onShowToast('✓ Sincronización completa con n8n: 4 disparadores actualizados');
    }, 1200);
  };

  return (
    <div className="flex flex-col w-full gap-4 pb-28 animate-in fade-in duration-300">
      {/* Control Header: View Switcher */}
      <section className="flex flex-col gap-2.5">
        <div className="bg-[#0a0e16] p-1 rounded-2xl flex items-center justify-between border border-white/5">
          <button
            onClick={() => setActiveTab('semanal')}
            className={`flex-1 py-1.5 px-2 rounded-xl font-mono text-xs flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'semanal'
                ? 'bg-[#262a33] text-[#4edea3] font-bold shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <span className="material-symbols-outlined text-[16px]">view_timeline</span>
            <span>Semanal</span>
          </button>
          <button
            onClick={() => setActiveTab('canal')}
            className={`flex-1 py-1.5 px-2 rounded-xl font-mono text-xs flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'canal'
                ? 'bg-[#262a33] text-[#4edea3] font-bold shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <span className="material-symbols-outlined text-[16px]">grid_view</span>
            <span>Canal</span>
          </button>
          <button
            onClick={() => setActiveTab('embudo')}
            className={`flex-1 py-1.5 px-2 rounded-xl font-mono text-xs flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'embudo'
                ? 'bg-[#262a33] text-[#4edea3] font-bold shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <span className="material-symbols-outlined text-[16px]">filter_alt</span>
            <span>Embudo</span>
          </button>
        </div>

        {/* Strategic Pillars Filter Horizontal Slider */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
          <button
            onClick={() => setSelectedPillar('all')}
            className={`shrink-0 px-3 py-1.5 rounded-full font-mono text-[10px] uppercase tracking-wider flex items-center gap-1.5 shadow-sm transition-all ${
              selectedPillar === 'all'
                ? 'bg-emerald-500 text-black font-bold'
                : 'bg-[#262a33] text-slate-300 hover:text-white'
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-black"></span>
            <span>Todos (25)</span>
          </button>
          <button
            onClick={() => setSelectedPillar('marca')}
            className={`shrink-0 px-3 py-1.5 rounded-full font-mono text-[10px] uppercase tracking-wider flex items-center gap-1.5 transition-all ${
              selectedPillar === 'marca'
                ? 'bg-emerald-500 text-black font-bold'
                : 'bg-[#262a33] text-slate-300 hover:text-white'
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-[#d0bcff]"></span>
            <span>Marca (12)</span>
          </button>
          <button
            onClick={() => setSelectedPillar('interaccion')}
            className={`shrink-0 px-3 py-1.5 rounded-full font-mono text-[10px] uppercase tracking-wider flex items-center gap-1.5 transition-all ${
              selectedPillar === 'interaccion'
                ? 'bg-emerald-500 text-black font-bold'
                : 'bg-[#262a33] text-slate-300 hover:text-white'
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-[#4cd7f6]"></span>
            <span>Interacción (8)</span>
          </button>
          <button
            onClick={() => setSelectedPillar('comunidad')}
            className={`shrink-0 px-3 py-1.5 rounded-full font-mono text-[10px] uppercase tracking-wider flex items-center gap-1.5 transition-all ${
              selectedPillar === 'comunidad'
                ? 'bg-emerald-500 text-black font-bold'
                : 'bg-[#262a33] text-slate-300 hover:text-white'
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-purple-400"></span>
            <span>Comunidad (4)</span>
          </button>
          <button
            onClick={() => setSelectedPillar('conversion')}
            className={`shrink-0 px-3 py-1.5 rounded-full font-mono text-[10px] uppercase tracking-wider flex items-center gap-1.5 transition-all ${
              selectedPillar === 'conversion'
                ? 'bg-emerald-500 text-black font-bold'
                : 'bg-[#262a33] text-slate-300 hover:text-white'
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-[#10b981]"></span>
            <span>Conversión (5)</span>
          </button>
        </div>
      </section>

      {/* Funnel Tracker: Visual Conversion Flow */}
      <section className="bg-[#181c24] rounded-2xl p-4 flex flex-col gap-3 shadow-md border border-white/5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#4edea3] text-[18px]">insights</span>
            <h2 className="font-display text-sm font-bold text-white">Embudo Multicanal 360</h2>
          </div>
          <span className="font-mono text-[9px] uppercase tracking-wider px-2 py-0.5 rounded bg-[#262a33] text-[#4edea3] font-bold border border-emerald-500/20">
            Live Pipeline
          </span>
        </div>

        {/* Funnel Segmented Cards */}
        <div className="grid grid-cols-3 gap-2">
          {/* TOFU */}
          <div className="bg-[#1c2028] p-2.5 rounded-xl flex flex-col gap-1 border border-white/5">
            <div className="flex items-center justify-between">
              <span className="font-mono text-[10px] font-bold uppercase text-purple-300">TOFU</span>
              <span className="font-mono text-[9px] text-slate-400">12 pcs</span>
            </div>
            <p className="font-display text-xl font-bold text-white leading-none mt-1">128k</p>
            <span className="text-[9.5px] text-slate-400 leading-tight">Alcance TikTok/Reels</span>
            <div className="w-full bg-[#262a33] h-1.5 rounded-full overflow-hidden mt-1">
              <div className="bg-purple-400 h-full rounded-full" style={{ width: '85%' }}></div>
            </div>
          </div>

          {/* MOFU */}
          <div className="bg-[#1c2028] p-2.5 rounded-xl flex flex-col gap-1 border border-white/5">
            <div className="flex items-center justify-between">
              <span className="font-mono text-[10px] font-bold uppercase text-cyan-300">MOFU</span>
              <span className="font-mono text-[9px] text-slate-400">8 pcs</span>
            </div>
            <p className="font-display text-xl font-bold text-white leading-none mt-1">14.2k</p>
            <span className="text-[9.5px] text-slate-400 leading-tight">Engage / Encuestas</span>
            <div className="w-full bg-[#262a33] h-1.5 rounded-full overflow-hidden mt-1">
              <div className="bg-cyan-400 h-full rounded-full" style={{ width: '64%' }}></div>
            </div>
          </div>

          {/* BOFU */}
          <div className="bg-[#1c2028] p-2.5 rounded-xl flex flex-col gap-1 border border-white/5">
            <div className="flex items-center justify-between">
              <span className="font-mono text-[10px] font-bold uppercase text-[#4edea3]">BOFU</span>
              <span className="font-mono text-[9px] text-slate-400">5 pcs</span>
            </div>
            <p className="font-display text-xl font-bold text-[#4edea3] leading-none mt-1">342</p>
            <span className="text-[9.5px] text-slate-400 leading-tight">Pedidos WhatsApp</span>
            <div className="w-full bg-[#262a33] h-1.5 rounded-full overflow-hidden mt-1">
              <div className="bg-emerald-400 h-full rounded-full" style={{ width: '92%' }}></div>
            </div>
          </div>
        </div>
      </section>

      {/* Weekly Grid / Calendar Stream */}
      <section className="flex flex-col gap-3">
        <div className="flex items-center justify-between px-0.5">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#4edea3] animate-pulse"></span>
            <h3 className="font-display text-base font-bold text-white">Parrilla Operativa</h3>
          </div>
          <div className="flex items-center gap-1 bg-[#262a33] px-2.5 py-1 rounded-xl border border-white/5">
            <span className="material-symbols-outlined text-[14px] text-[#4edea3]">cloud_sync</span>
            <span className="font-mono text-[10px] text-slate-300">Sync n8n: 4m ago</span>
          </div>
        </div>

        {/* Feed of Strategic Content Pieces */}
        <div className="flex flex-col gap-3">
          {filteredPosts.map((post) => (
            <article
              key={post.id}
              className="bg-[#181c24] rounded-2xl overflow-hidden p-3.5 flex flex-col gap-2.5 shadow-md border border-white/5 hover:border-emerald-500/25 transition-all"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded-lg bg-emerald-500/20 text-[#4edea3] font-mono text-[10px] uppercase font-bold border border-emerald-500/30">
                    {post.dayLabel}
                  </span>
                  <span className="px-2 py-0.5 rounded-lg bg-[#262a33] text-slate-300 font-mono text-[9px] uppercase">
                    {post.pillarLabel}
                  </span>
                </div>

                <div className="flex items-center gap-1.5 text-slate-400">
                  {post.channels.includes('whatsapp') && (
                    <span className="material-symbols-outlined text-[16px] text-emerald-400">chat</span>
                  )}
                  {post.channels.includes('instagram') && (
                    <span className="material-symbols-outlined text-[16px] text-pink-400">photo_camera</span>
                  )}
                  {post.channels.includes('tiktok') && (
                    <span className="material-symbols-outlined text-[16px] text-cyan-400">video_library</span>
                  )}
                  {post.channels.includes('youtube') && (
                    <span className="material-symbols-outlined text-[16px] text-rose-400">smart_display</span>
                  )}
                </div>
              </div>

              <div className="flex gap-3">
                <div className="relative w-20 h-24 rounded-xl overflow-hidden shrink-0 bg-[#1c2028] border border-white/5">
                  <img
                    className="w-full h-full object-cover"
                    src={post.imageUrl}
                    alt={post.title}
                  />
                  <span className="absolute bottom-1 right-1 px-1.5 py-0.2 rounded bg-black/80 text-[#4edea3] font-mono text-[8.5px] font-bold">
                    {post.ratioBadge}
                  </span>
                </div>

                <div className="flex flex-col justify-between flex-1 min-w-0">
                  <div>
                    <h4 className="font-display text-xs font-bold text-white truncate">
                      {post.title}
                    </h4>
                    <p className="text-xs text-slate-400 line-clamp-2 mt-0.5 leading-relaxed">
                      {post.description}
                    </p>
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <span className="font-mono text-[10px] text-[#4edea3] flex items-center gap-1">
                      <span className="material-symbols-outlined text-[13px]">bolt</span> {post.statusText}
                    </span>
                    <span className="font-mono text-[10px] text-slate-400">{post.time}</span>
                  </div>
                </div>
              </div>

              {/* Card Action Footer */}
              {post.actionLabel ? (
                <div className="flex items-center justify-between gap-2 pt-1 border-t border-white/5">
                  <button
                    onClick={() => onShowToast(`¡Publicación disparada para "${post.title}" vía n8n!`)}
                    className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 text-black font-mono text-xs font-bold flex items-center justify-center gap-1.5 shadow-md active:scale-98 transition-all"
                  >
                    <span className="material-symbols-outlined text-[16px]">send</span>
                    <span>{post.actionLabel}</span>
                  </button>
                  <button
                    onClick={() => onChangeView('studio-canvas')}
                    aria-label="Ajustar parámetros"
                    className="p-2 rounded-xl bg-[#262a33] text-slate-300 hover:text-white flex items-center justify-center shrink-0 border border-white/5"
                  >
                    <span className="material-symbols-outlined text-[18px]">tune</span>
                  </button>
                </div>
              ) : (
                <div className="flex items-center justify-between pt-1 border-t border-white/5 text-[10px] font-mono text-slate-400">
                  <span className="flex items-center gap-1 text-slate-300">
                    <span className="material-symbols-outlined text-[14px] text-cyan-400">check_circle</span>
                    Trigger n8n configurado
                  </span>
                  <button
                    onClick={() => onChangeView('studio-canvas')}
                    className="text-cyan-400 hover:underline font-semibold"
                  >
                    Ver canvas
                  </button>
                </div>
              )}
            </article>
          ))}
        </div>
      </section>

      {/* Matriz de Coherencia Visual & Brand Assets */}
      <section className="bg-[#181c24] rounded-2xl p-4 flex flex-col gap-2.5 shadow-md border border-white/5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <span className="material-symbols-outlined text-cyan-400 text-[18px]">verified</span>
            <h3 className="font-display text-xs font-bold text-white">Coherencia de Marca {activeBrand.name}</h3>
          </div>
          <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/20 text-[#4edea3] border border-emerald-500/30">
            <span className="font-mono text-[10px] font-bold">98% OK</span>
          </div>
        </div>

        {/* Detail Grid */}
        <div className="grid grid-cols-3 gap-2 pt-1">
          <div className="bg-[#1c2028] p-2 rounded-xl flex flex-col gap-1 border border-white/5">
            <div className="flex items-center gap-1 text-slate-400">
              <span className="material-symbols-outlined text-[14px] text-amber-400">palette</span>
              <span className="font-mono text-[9px]">Paleta</span>
            </div>
            <span className="text-xs font-bold text-white">Gold & Warm</span>
            <div className="flex items-center gap-1 mt-0.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#D4AF37]" title="Gold"></span>
              <span className="w-2.5 h-2.5 rounded-full bg-[#8B5A2B]" title="Warm crust"></span>
              <span className="w-2.5 h-2.5 rounded-full bg-[#4edea3]" title="Emerald accent"></span>
            </div>
          </div>

          <div className="bg-[#1c2028] p-2 rounded-xl flex flex-col gap-1 border border-white/5">
            <div className="flex items-center gap-1 text-slate-400">
              <span className="material-symbols-outlined text-[14px] text-cyan-400">match_case</span>
              <span className="font-mono text-[9px]">Fuentes</span>
            </div>
            <span className="text-xs font-bold text-white">Space & Inter</span>
            <span className="font-mono text-[9px] text-slate-400 mt-0.5">Sincronizadas</span>
          </div>

          <div className="bg-[#1c2028] p-2 rounded-xl flex flex-col gap-1 border border-white/5">
            <div className="flex items-center gap-1 text-slate-400">
              <span className="material-symbols-outlined text-[14px] text-purple-400">record_voice_over</span>
              <span className="font-mono text-[9px]">Voz IA</span>
            </div>
            <span className="text-xs font-bold text-white truncate">Cálida & Genuina</span>
            <span className="font-mono text-[9px] text-emerald-400 mt-0.5">Auditada LLM</span>
          </div>
        </div>
      </section>

      {/* Floating Quick Actions Bar */}
      <section className="bg-[#262a33]/90 backdrop-blur-xl p-3 rounded-2xl flex flex-col gap-2 shadow-xl border border-white/10">
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={handleSyncN8n}
            className="py-2.5 px-3 rounded-xl bg-[#31353e] hover:bg-[#3c424e] text-white font-mono text-xs flex items-center justify-center gap-1.5 active:scale-98 transition-all font-semibold"
          >
            <span className={`material-symbols-outlined text-[#4edea3] text-[18px] ${syncSpin ? 'animate-spin' : ''}`}>
              sync
            </span>
            <span>Sincronizar n8n</span>
          </button>
          <button
            onClick={() => onShowToast('Copilot 360: Auditoría de parrilla completada, 0 conflictos encontrados')}
            className="py-2.5 px-3 rounded-xl bg-purple-600/30 text-purple-200 border border-purple-500/40 hover:bg-purple-600/40 font-mono text-xs flex items-center justify-center gap-1.5 active:scale-98 transition-all font-semibold"
          >
            <span className="material-symbols-outlined text-[18px]">auto_fix_high</span>
            <span>Copilot 360</span>
          </button>
        </div>

        <button
          onClick={() => onChangeView('studio-canvas')}
          className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-400 to-teal-400 hover:from-emerald-300 hover:to-teal-300 text-black font-display text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 active:scale-98 transition-all"
        >
          <span className="material-symbols-outlined text-[20px]">add_circle</span>
          <span>Nueva Pieza Estratégica</span>
        </button>
      </section>
    </div>
  );
};
