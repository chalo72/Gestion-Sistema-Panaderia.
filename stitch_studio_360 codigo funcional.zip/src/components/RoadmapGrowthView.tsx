import React, { useState } from 'react';
import { BrandProfile, ScreenView } from '../types';
import { DAILY_MISSIONS } from '../data';

interface RoadmapGrowthViewProps {
  activeBrand: BrandProfile;
  onChangeView: (view: ScreenView) => void;
  onShowToast: (msg: string) => void;
}

export const RoadmapGrowthView: React.FC<RoadmapGrowthViewProps> = ({
  activeBrand,
  onChangeView,
  onShowToast
}) => {
  const [missions, setMissions] = useState(DAILY_MISSIONS);
  const [viewsSlider, setViewsSlider] = useState<number>(78); // in thousands (78k)

  // Dynamic calculations based on views slider
  const estimatedRevenue = Math.round((viewsSlider / 78) * 4850);
  const estimatedOrders = Math.round((viewsSlider / 78) * 342);
  const calculatedGrowthRate = Math.round(120 + (viewsSlider - 50) * 1.2);

  const toggleMission = (id: string) => {
    setMissions((prev) =>
      prev.map((m) => {
        if (m.id === id) {
          const newState = !m.completed;
          onShowToast(newState ? `✓ Misión completada: "${m.title}"` : `Misión desmarcada`);
          return { ...m, completed: newState };
        }
        return m;
      })
    );
  };

  return (
    <div className="flex flex-col w-full gap-4 pb-28 animate-in fade-in duration-300">
      {/* Nivel de Creador & Barra de Progreso a Escala */}
      <section className="bg-gradient-to-br from-[#1c2028] via-[#161b24] to-[#12161e] rounded-2xl p-4 border border-emerald-500/25 shadow-xl relative overflow-hidden">
        <div className="absolute -right-8 -bottom-8 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none"></div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-xl bg-emerald-500/20 text-[#4edea3] flex items-center justify-center font-bold text-xs border border-emerald-500/30">
              L3
            </span>
            <div>
              <span className="font-mono text-[9px] text-[#4edea3] uppercase tracking-wider font-bold">
                Nivel Actual · Creador Emergente
              </span>
              <h2 className="font-display text-sm font-bold text-white">
                {activeBrand.name}
              </h2>
            </div>
          </div>
          <span className="font-mono text-[10px] text-slate-400 bg-[#0a0e16] px-2 py-0.5 rounded-full border border-white/5">
            50k - 100k views/mes
          </span>
        </div>

        {/* Stepper Steps (L1 -> L4) */}
        <div className="grid grid-cols-4 gap-1.5 mt-3 pt-1">
          <div className="bg-[#0a0e16] p-1.5 rounded-xl text-center border border-white/5">
            <span className="text-[9px] font-mono text-slate-500 block">L1 Starter</span>
            <span className="text-[10px] font-bold text-slate-400">5k</span>
          </div>
          <div className="bg-[#0a0e16] p-1.5 rounded-xl text-center border border-white/5">
            <span className="text-[9px] font-mono text-slate-500 block">L2 Tracción</span>
            <span className="text-[10px] font-bold text-slate-400">20k</span>
          </div>
          <div className="bg-emerald-500/20 p-1.5 rounded-xl text-center border border-emerald-500/40">
            <span className="text-[9px] font-mono text-[#4edea3] font-bold block">L3 Actual</span>
            <span className="text-[10px] font-bold text-white">{viewsSlider}k</span>
          </div>
          <div className="bg-[#0a0e16] p-1.5 rounded-xl text-center border border-white/5">
            <span className="text-[9px] font-mono text-purple-400 block">L4 Autor</span>
            <span className="text-[10px] font-bold text-slate-400">250k</span>
          </div>
        </div>

        {/* Progress Towards Level 4 */}
        <div className="space-y-1.5 mt-3">
          <div className="flex items-center justify-between font-mono text-[10px] text-slate-300">
            <span>Meta: Nivel 4 · Creador Autor</span>
            <span className="text-[#4edea3] font-bold">68% completado</span>
          </div>
          <div className="w-full bg-[#0a0e16] h-2 rounded-full overflow-hidden p-0.5 border border-white/5">
            <div
              className="bg-gradient-to-r from-emerald-500 to-[#4edea3] h-full rounded-full transition-all duration-500"
              style={{ width: '68%' }}
            ></div>
          </div>
          <p className="text-[9.5px] text-slate-400 font-mono text-right">
            {viewsSlider}k de 100k views necesarios para el siguiente salto algorítmico
          </p>
        </div>
      </section>

      {/* Métricas de Crecimiento Rápido & Viralidad (Bento Grid) */}
      <section className="space-y-2">
        <div className="flex items-center justify-between px-0.5">
          <h3 className="font-display text-sm font-bold text-white flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[#4edea3] text-[18px]">trending_up</span>
            Métricas de Viralidad & Tracción
          </h3>
          <span className="font-mono text-[10px] text-slate-400">Últimos 30 días</span>
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          {/* Card 1: Video Views */}
          <div className="bg-[#181c24] p-3 rounded-2xl border border-white/5 flex flex-col justify-between shadow-sm">
            <div className="flex items-center justify-between text-slate-400">
              <span className="text-xs">Vistas Video</span>
              <span className="material-symbols-outlined text-[16px] text-purple-400">play_circle</span>
            </div>
            <div className="my-1">
              <span className="font-display text-xl font-bold text-white">480k</span>
              <span className="text-[10px] font-mono text-[#4edea3] block font-semibold">
                ↑ +{calculatedGrowthRate}% vs mes anterior
              </span>
            </div>
            <span className="text-[9px] text-slate-400">Reels & TikTok sincronizados</span>
          </div>

          {/* Card 2: Hook Retention 3s */}
          <div className="bg-[#181c24] p-3 rounded-2xl border border-white/5 flex flex-col justify-between shadow-sm">
            <div className="flex items-center justify-between text-slate-400">
              <span className="text-xs">Retención 3s</span>
              <span className="material-symbols-outlined text-[16px] text-cyan-400">timer</span>
            </div>
            <div className="my-1">
              <span className="font-display text-xl font-bold text-white">68%</span>
              <span className="text-[10px] font-mono text-cyan-400 block font-semibold">
                ↑ +12% benchmark pastelería
              </span>
            </div>
            <span className="text-[9px] text-slate-400">Sonido crujiente ASMR</span>
          </div>

          {/* Card 3: VIP Followers */}
          <div className="bg-[#181c24] p-3 rounded-2xl border border-white/5 flex flex-col justify-between shadow-sm">
            <div className="flex items-center justify-between text-slate-400">
              <span className="text-xs">Seguidores VIP</span>
              <span className="material-symbols-outlined text-[16px] text-emerald-400">group_add</span>
            </div>
            <div className="my-1">
              <span className="font-display text-xl font-bold text-white">+2,400</span>
              <span className="text-[10px] font-mono text-[#4edea3] block font-semibold">
                +420 esta semana
              </span>
            </div>
            <span className="text-[9px] text-slate-400">Tráfico orgánico 100%</span>
          </div>

          {/* Card 4: Projected Revenue */}
          <div className="bg-[#181c24] p-3 rounded-2xl border border-white/5 flex flex-col justify-between shadow-sm">
            <div className="flex items-center justify-between text-slate-400">
              <span className="text-xs">Proyección Ventas</span>
              <span className="material-symbols-outlined text-[16px] text-amber-400">paid</span>
            </div>
            <div className="my-1">
              <span className="font-display text-xl font-bold text-[#4edea3]">${estimatedRevenue}</span>
              <span className="text-[10px] font-mono text-slate-300 block font-semibold">
                {estimatedOrders} pedidos WhatsApp
              </span>
            </div>
            <span className="text-[9px] text-slate-400 font-mono">Atribuido a n8n</span>
          </div>
        </div>
      </section>

      {/* Copilot Algoritmo Viral HUD Alert */}
      <section className="bg-[#181c24] rounded-2xl p-4 border border-purple-500/30 shadow-md">
        <div className="flex items-start gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-300 flex items-center justify-center shrink-0 border border-purple-500/40">
            <span className="material-symbols-outlined text-[20px]">smart_toy</span>
          </div>
          <div className="flex-1 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white">Copilot Algoritmo Viral</span>
              <span className="text-[9px] px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 font-mono font-bold">
                HACK DEL DÍA
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              El gancho de <strong className="text-purple-300">“primer plano crujiente con sonido amplificado”</strong> retiene 3.2x más usuarios que los planos generales. Te sugerimos publicar entre las <strong className="text-emerald-400">18:30 y 19:15 hrs</strong>.
            </p>
            <div className="flex flex-wrap gap-1.5 pt-1">
              <button
                onClick={() => {
                  onChangeView('studio-canvas');
                  onShowToast('Guión con gancho ASMR generado en Studio Canvas');
                }}
                className="px-2.5 py-1.5 rounded-lg bg-purple-600/30 text-purple-200 border border-purple-500/40 text-[10px] font-mono font-semibold flex items-center gap-1 active:scale-95"
              >
                <span className="material-symbols-outlined text-[13px]">mic</span>
                <span>Generar Guión Viral con Hook ASMR</span>
              </button>
              <button
                onClick={() => onShowToast('Disparo programado para las 18:30 hrs en Instagram y TikTok')}
                className="px-2.5 py-1.5 rounded-lg bg-[#262a33] text-slate-300 text-[10px] font-mono flex items-center gap-1 active:scale-95 hover:text-white"
              >
                <span className="material-symbols-outlined text-[13px]">schedule</span>
                <span>Programar en Hora Pico</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Simulador Interactivo de Monetización y Tracción */}
      <section className="bg-[#181c24] rounded-2xl p-4 border border-white/5 flex flex-col gap-3 shadow-md">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-amber-400 text-[18px]">calculate</span>
            <h3 className="font-display text-xs font-bold text-white">Simulador de Monetización Omnicanal</h3>
          </div>
          <span className="font-mono text-[10px] text-amber-400 font-bold">En Vivo</span>
        </div>

        <div className="space-y-2 bg-[#12161e] p-3 rounded-xl border border-white/5">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-300">Vistas Mensuales Estimadas:</span>
            <span className="font-mono text-emerald-400 font-bold">{viewsSlider},000 views</span>
          </div>
          <input
            type="range"
            min="30"
            max="250"
            step="5"
            value={viewsSlider}
            onChange={(e) => setViewsSlider(Number(e.target.value))}
            className="w-full accent-emerald-400 h-2 bg-[#262a33] rounded-lg cursor-pointer"
          />
          <div className="flex justify-between text-[9px] font-mono text-slate-500">
            <span>30k (Básico)</span>
            <span>100k (L3 Creador)</span>
            <span>250k (L4 Autor)</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 text-center">
          <div className="bg-[#12161e] p-2.5 rounded-xl border border-white/5">
            <span className="text-[10px] font-mono text-slate-400 block">Ingresos Estimados:</span>
            <span className="font-display text-lg font-bold text-[#4edea3]">${estimatedRevenue} USD</span>
          </div>
          <div className="bg-[#12161e] p-2.5 rounded-xl border border-white/5">
            <span className="text-[10px] font-mono text-slate-400 block">Pedidos por WhatsApp:</span>
            <span className="font-display text-lg font-bold text-white">{estimatedOrders} pedidos</span>
          </div>
        </div>
      </section>

      {/* Misiones Diarias Gamificadas */}
      <section className="space-y-2.5">
        <div className="flex items-center justify-between px-0.5">
          <h3 className="font-display text-sm font-bold text-white flex items-center gap-1.5">
            <span className="material-symbols-outlined text-emerald-400 text-[18px]">task_alt</span>
            Misiones Diarias de Aceleración
          </h3>
          <span className="font-mono text-[10px] text-slate-400">
            {missions.filter((m) => m.completed).length} de {missions.length} listas
          </span>
        </div>

        <div className="space-y-2">
          {missions.map((mission) => (
            <div
              key={mission.id}
              onClick={() => toggleMission(mission.id)}
              className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-start justify-between gap-3 ${
                mission.completed
                  ? 'bg-[#181c24]/50 border-slate-800 opacity-75'
                  : 'bg-[#181c24] border-white/5 hover:border-emerald-500/30'
              }`}
            >
              <div className="flex items-start gap-2.5 min-w-0">
                <button
                  type="button"
                  aria-label={mission.completed ? `Marcar incompleta ${mission.title}` : `Marcar completada ${mission.title}`}
                  className={`mt-0.5 w-5 h-5 rounded-md flex items-center justify-center border transition-all ${
                    mission.completed
                      ? 'bg-emerald-500 text-black border-emerald-500'
                      : 'border-slate-600 bg-[#0a0e16]'
                  }`}
                >
                  {mission.completed && <span className="material-symbols-outlined text-[14px]">check</span>}
                </button>
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className={`text-xs font-bold ${mission.completed ? 'line-through text-slate-400' : 'text-white'}`}>
                      {mission.title}
                    </span>
                    <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-[#262a33] text-[#4edea3]">
                      {mission.badge}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 leading-tight">{mission.description}</p>
                  {mission.hook && (
                    <span className="text-[10px] font-mono text-purple-300 block italic">
                      Gancho sugerido: {mission.hook}
                    </span>
                  )}
                </div>
              </div>

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onChangeView('studio-canvas');
                  onShowToast(`Abriendo asistente para "${mission.title}"`);
                }}
                className="shrink-0 px-2.5 py-1 rounded-lg bg-[#262a33] hover:bg-[#343a46] text-slate-200 text-[10px] font-mono font-semibold"
              >
                {mission.actionText}
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Radar de Tendencias Gastronómicas en Directo */}
      <section className="bg-[#181c24] rounded-2xl p-4 border border-white/5 space-y-2.5 shadow-md">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-cyan-400 text-[18px]">radar</span>
            <h3 className="font-display text-xs font-bold text-white">Radar de Tendencias de Pastelería</h3>
          </div>
          <span className="text-[9px] font-mono text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded-full">
            Actualizado hace 12 min
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="bg-[#12161e] p-2.5 rounded-xl border border-white/5 space-y-1">
            <span className="text-[9px] font-mono text-slate-400 uppercase">Audio en Viralidad</span>
            <div className="font-bold text-white truncate">🎵 Cafe Parisien Accordion</div>
            <span className="text-[9px] font-mono text-[#4edea3]">+340% esta semana</span>
          </div>

          <div className="bg-[#12161e] p-2.5 rounded-xl border border-white/5 space-y-1">
            <span className="text-[9px] font-mono text-slate-400 uppercase">Formato Recomendado</span>
            <div className="font-bold text-white truncate">📹 POV: Horneando a las 4 AM</div>
            <span className="text-[9px] font-mono text-purple-300">Retención 82%</span>
          </div>
        </div>
      </section>

      {/* Botón Principal de Sprint 10X */}
      <button
        onClick={() => onShowToast('🚀 Sprint 10X Activado: Generando batería de 3 Reels con gancho ASMR')}
        className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-emerald-500 hover:from-purple-500 hover:to-emerald-400 text-white font-display text-xs font-extrabold flex items-center justify-center gap-2 shadow-xl shadow-purple-600/25 active:scale-98 transition-all"
      >
        <span className="material-symbols-outlined text-[18px]">rocket_launch</span>
        <span>Activar Sprint de Crecimiento 10X</span>
      </button>
    </div>
  );
};
