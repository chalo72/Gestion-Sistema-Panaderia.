import React from 'react';
import { ScreenView } from '../types';

interface BottomNavProps {
  currentView: ScreenView;
  onChangeView: (view: ScreenView) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentView, onChangeView }) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 pb-safe bg-[#0a0e16]/95 backdrop-blur-xl border-t border-[#262a33]/80 shadow-[0_-4px_20px_rgba(0,0,0,0.6)]">
      <div className="flex items-center justify-around h-16 max-w-md mx-auto px-1">
        {/* Estrategia 360 */}
        <button
          onClick={() => onChangeView('estrategia')}
          className={`min-h-[44px] min-w-[44px] flex-1 flex flex-col items-center justify-center py-1 rounded-xl transition-all ${
            currentView === 'estrategia'
              ? 'text-[#4edea3] bg-[#262a33]/70 font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <span className="material-symbols-outlined text-[20px]">hub</span>
          <span className="font-mono text-[9.5px] mt-0.5 tracking-tight">Estrategia 360</span>
        </button>

        {/* Studio Canvas */}
        <button
          onClick={() => onChangeView('studio-canvas')}
          className={`min-h-[44px] min-w-[44px] flex-1 flex flex-col items-center justify-center py-1 rounded-xl transition-all ${
            currentView === 'studio-canvas'
              ? 'text-[#4edea3] bg-[#262a33]/70 font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <span className="material-symbols-outlined text-[20px]">draw</span>
          <span className="font-mono text-[9.5px] mt-0.5 tracking-tight">Studio Canvas</span>
        </button>

        {/* Calendario / Parrilla */}
        <button
          onClick={() => onChangeView('calendario')}
          className={`min-h-[44px] min-w-[44px] flex-1 flex flex-col items-center justify-center py-1 rounded-xl transition-all ${
            currentView === 'calendario'
              ? 'text-[#4edea3] bg-[#262a33]/70 font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <span className="material-symbols-outlined text-[20px]">calendar_month</span>
          <span className="font-mono text-[9.5px] mt-0.5 tracking-tight">Calendario</span>
        </button>

        {/* Roadmap / Métricas ROI */}
        <button
          onClick={() => onChangeView('roadmap')}
          className={`min-h-[44px] min-w-[44px] flex-1 flex flex-col items-center justify-center py-1 rounded-xl transition-all ${
            currentView === 'roadmap'
              ? 'text-[#4edea3] bg-[#262a33]/70 font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <span className="material-symbols-outlined text-[20px]">monitoring</span>
          <span className="font-mono text-[9.5px] mt-0.5 tracking-tight">Métricas/ROI</span>
        </button>

        {/* Hub Master & 4-Pasos */}
        <button
          onClick={() => onChangeView('hub-central')}
          className={`min-h-[44px] min-w-[44px] flex-1 flex flex-col items-center justify-center py-1 rounded-xl transition-all ${
            currentView === 'hub-central' || currentView === 'asistente-4pasos'
              ? 'text-[#4edea3] bg-[#262a33]/70 font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <span className="material-symbols-outlined text-[20px]">grid_view</span>
          <span className="font-mono text-[9.5px] mt-0.5 tracking-tight">Hub 360°</span>
        </button>
      </div>
    </nav>
  );
};
