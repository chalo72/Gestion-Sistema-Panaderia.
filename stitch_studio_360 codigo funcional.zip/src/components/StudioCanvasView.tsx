import React, { useState } from 'react';
import { BrandProfile } from '../types';
import { FX_FILTERS } from '../data';

interface StudioCanvasViewProps {
  activeBrand: BrandProfile;
  onShowToast: (msg: string) => void;
  onOpenQuickPublish: () => void;
}

export const StudioCanvasView: React.FC<StudioCanvasViewProps> = ({
  activeBrand,
  onShowToast,
  onOpenQuickPublish
}) => {
  // Canvas State
  const [aspectRatio, setAspectRatio] = useState<'1:1' | '9:16' | '4:5'>('1:1');
  const [activeFilterId, setActiveFilterId] = useState<string>('cinematic-gold');
  const [activeFont, setActiveFont] = useState<'font-syne' | 'font-bebas' | 'font-playfair' | 'font-sans'>('font-syne');
  const [fontSize, setFontSize] = useState<number>(22);
  const [headline, setHeadline] = useState<string>('¡Amor Horneado Fresco!');
  const [subheadline, setSubheadline] = useState<string>('Hojaldre de mantequilla y fresas silvestres');
  const [badgeText, setBadgeText] = useState<string>('2X1 HOY');
  const [ctaLabel, setCtaLabel] = useState<string>('Pedir WhatsApp');
  const [priceTag, setPriceTag] = useState<string>('$6.50');
  const [activeTab, setActiveTab] = useState<'fx' | 'typo' | 'stickers'>('fx');
  const [isGuidesActive, setIsGuidesActive] = useState<boolean>(false);
  const [isAbActive, setIsAbActive] = useState<boolean>(false);

  // AI Chat State
  const [aiInput, setAiInput] = useState<string>('');
  const [aiMessage, setAiMessage] = useState<string>(
    'He optimizado el contraste y aplicado Cinematic Gold. ¿Quieres que redacte un hook más persuasivo para TikTok o ajusto la tipografía al titular?'
  );
  const [isDispatching, setIsDispatching] = useState<boolean>(false);

  const activeFilter = FX_FILTERS.find((f) => f.id === activeFilterId) || FX_FILTERS[0];

  const handleApplyQuickPrompt = (promptText: string) => {
    setAiInput(promptText);
    executeAiEdit(promptText);
  };

  const executeAiEdit = (promptText: string) => {
    const p = promptText.toLowerCase();
    if (p.includes('elegante') || p.includes('parejas')) {
      setHeadline('¡Amistad que endulza el alma!');
      setSubheadline('El aroma a masa madre dorada para compartir hoy.');
      setActiveFont('font-playfair');
      setActiveFilterId('cinematic-gold');
      setAiMessage('Apliqué tipografía Playfair Serif elegante y realcé el tono cálido dorado para parejas.');
      onShowToast('✨ Estilo elegante aplicado al canvas');
    } else if (p.includes('display') || p.includes('bold') || p.includes('fuente')) {
      setActiveFont('font-syne');
      setFontSize(26);
      setHeadline('¿POR QUÉ NUNCA VISTE ESTE HOJALDRE? 🥐');
      setAiMessage('Tipografía cambiada a Syne Bold (Display 26px) con alto impacto de lectura rápida.');
      onShowToast('🔤 Fuente Display aplicada');
    } else if (p.includes('urgente') || p.includes('oferta') || p.includes('flash')) {
      setBadgeText('🔥 ÚLTIMAS 15 CAJAS');
      setHeadline('¡2x1 Solo Hasta las 14:00!');
      setPriceTag('$5.90');
      setCtaLabel('Apartar Caja Flash');
      setAiMessage('Generé sentido de escasez (FOMO): precio de oferta $5.90 y badge de urgencia.');
      onShowToast('🔥 Modo oferta urgente activado');
    } else if (p.includes('hojaldre') || p.includes('croissant') || p.includes('crujiente')) {
      setHeadline('Mantequilla Pura & 72 Capas Crujientes');
      setSubheadline('Horneado artesanal cada 2 horas en Dulce Placer.');
      setActiveFilterId('cinematic-gold');
      setAiMessage('Enfoque sensorial calibrado: resaltando hojaldrado en caliente y aroma a mantequilla.');
      onShowToast('🥐 Enfoque sensorial aplicado');
    } else {
      setHeadline(`"${promptText.slice(0, 36)}..."`);
      setAiMessage(`Modificación aplicada según tu indicación: "${promptText}".`);
      onShowToast('Ajuste de Copilot realizado');
    }
  };

  const handleDispatchN8n = () => {
    setIsDispatching(true);
    setTimeout(() => {
      setIsDispatching(false);
      onShowToast('¡Campaña Aprobada y Distribuida vía n8n a Instagram, TikTok y WhatsApp!');
    }, 1400);
  };

  return (
    <div className="flex flex-col w-full gap-4 pb-28 animate-in fade-in duration-300">
      {/* Ratio Selector & Guías Bar */}
      <div className="flex items-center justify-between gap-2 px-1">
        <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-1.5 font-mono">
          <span className="w-1.5 h-1.5 rounded-full bg-purple-400"></span> Canvas Visual
        </span>

        <div className="flex items-center gap-1 bg-[#161B22] p-0.5 rounded-xl border border-slate-800">
          <button
            onClick={() => setAspectRatio('1:1')}
            className={`px-2.5 py-1 text-[10px] rounded-lg font-semibold transition-all ${
              aspectRatio === '1:1'
                ? 'bg-purple-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            1:1 Feed
          </button>
          <button
            onClick={() => setAspectRatio('9:16')}
            className={`px-2.5 py-1 text-[10px] rounded-lg font-semibold transition-all ${
              aspectRatio === '9:16'
                ? 'bg-purple-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            9:16 Story
          </button>
          <button
            onClick={() => setAspectRatio('4:5')}
            className={`px-2.5 py-1 text-[10px] rounded-lg font-semibold transition-all ${
              aspectRatio === '4:5'
                ? 'bg-purple-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            4:5 Post
          </button>

          <div className="h-4 w-px bg-slate-700 mx-0.5"></div>

          <button
            onClick={() => {
              setIsGuidesActive(!isGuidesActive);
              onShowToast(isGuidesActive ? 'Guías ocultas' : 'Guías seguras visibles');
            }}
            title="Guías de seguridad"
            className={`p-1 rounded text-[10px] ${isGuidesActive ? 'text-[#4edea3]' : 'text-slate-500'}`}
          >
            <span className="material-symbols-outlined text-[14px]">grid_4x4</span>
          </button>
          <button
            onClick={() => {
              setIsAbActive(!isAbActive);
              onShowToast(isAbActive ? 'Split A/B Desactivado' : 'Split A/B Activado: Versión B lista');
            }}
            title="Split A/B"
            className={`px-1.5 py-0.5 rounded text-[9px] font-mono font-bold ${
              isAbActive ? 'bg-amber-500/20 text-amber-300 border border-amber-400/40' : 'text-slate-500'
            }`}
          >
            A/B
          </button>
        </div>
      </div>

      {/* Mockup Canvas Interactivo con Badges Flotantes */}
      <div className="relative bg-[#1E2633] rounded-2xl border border-slate-800 overflow-hidden shadow-2xl group">
        {/* Badges Flotantes de FX & Font */}
        <div className="absolute top-2.5 inset-x-2.5 flex items-center justify-between z-20 pointer-events-none">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-black/70 backdrop-blur-md border border-amber-500/40 text-amber-300 text-[10px] font-mono shadow-sm">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse"></span>
            FX: {activeFilter.name}
          </div>
          <div className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-black/70 backdrop-blur-md border border-purple-500/40 text-purple-300 text-[10px] font-mono shadow-sm">
            <span>🔤 {activeFont === 'font-syne' ? 'Syne Bold' : activeFont === 'font-bebas' ? 'Bebas Neue' : activeFont === 'font-playfair' ? 'Playfair' : 'Inter'} • {fontSize}px</span>
          </div>
        </div>

        {/* Guías Seguras Overlay */}
        {isGuidesActive && (
          <div className="absolute inset-0 z-20 pointer-events-none p-4">
            <div className="w-full h-full border border-dashed border-[#4edea3]/50 rounded-xl flex items-between justify-between flex-col p-1 text-[9px] font-mono text-[#4edea3]">
              <div className="text-right">Top Safe Zone</div>
              <div className="text-right">Bottom Safe Zone (CTA)</div>
            </div>
          </div>
        )}

        {/* Visual del Post / Canvas Stage */}
        <div
          className={`relative w-full overflow-hidden flex items-end p-4 bg-gradient-to-t from-black/95 via-black/35 to-transparent transition-all duration-300 ${
            aspectRatio === '1:1'
              ? 'aspect-square'
              : aspectRatio === '9:16'
              ? 'aspect-[9/16] min-h-[420px]'
              : 'aspect-[4/5]'
          }`}
        >
          {/* Main Bakery Subject Image with selected dynamic FX */}
          <img
            alt="Croissant hojaldrado con fresas artesanal"
            className={`absolute inset-0 w-full h-full object-cover transition-all duration-500 scale-[1.01] ${activeFilter.cssClass}`}
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuBKIZ1AqizmrnWwmqugBDzEYAWUJW2UbixCsrPVQy82DBZsLQX9xr3udewGes8LxeH3lVj2DY_ZytwYQpRDEHcFWOrckp4CXKOSP5q3oTEVhqzOV7hm2diwa1tB2sTOh8gikh6GWNkUunrc2XHPU_pat2PCbMLhw_sNGVEidJZym2DwI_gZvffNqbBFkh6rvfq-Ch5q7pq57_zThSNHrc7AcX55BZ49Uc0jmVuoG4zrKNmKDgFm7q5uSQ"
          />

          {/* Gradients */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-black/20 pointer-events-none"></div>

          {/* Contenido Superpuesto en el Banner */}
          <div className="relative z-10 w-full flex flex-col justify-end gap-2">
            <div className="flex items-center gap-2">
              <span className="inline-block px-2 py-0.5 rounded bg-rose-600 text-white font-black text-[9px] uppercase tracking-wider shadow-md">
                {badgeText}
              </span>
              <span className="px-2 py-0.5 rounded bg-black/60 backdrop-blur-sm text-amber-300 border border-amber-400/40 text-[9px] font-mono font-bold">
                {priceTag}
              </span>
            </div>

            <div className="space-y-1">
              <h3
                style={{ fontSize: `${fontSize}px` }}
                className={`font-black text-white leading-tight tracking-tight drop-shadow-lg ${activeFont}`}
              >
                {headline}
              </h3>
              <p className="text-xs text-slate-200 line-clamp-2 drop-shadow">
                {subheadline}
              </p>
            </div>

            <div className="flex items-center justify-between pt-1">
              <span className="text-[10px] text-slate-300 font-mono flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-[#4edea3]"></span>
                {activeBrand.name}
              </span>
              <button
                onClick={() => onShowToast(`Abriendo WhatsApp con: "${headline}"`)}
                className="px-3 py-1 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-[11px] flex items-center gap-1 shadow-lg shadow-emerald-500/30 active:scale-95 transition-all"
              >
                <span>💬</span>
                <span>{ctaLabel}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Mini Barra de Estado del Canvas */}
        <div className="px-3 py-2 bg-[#12161E] border-t border-slate-800 flex items-center justify-between text-[10px] text-slate-400">
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
            Render Ultra-HD IA listo
          </span>
          <button
            onClick={() => onShowToast('Capas sincronizadas: Fondo, Tipografía, Botón CTA, Filtro FX')}
            className="text-purple-400 hover:underline flex items-center gap-0.5"
          >
            Ajustar capas
          </button>
        </div>
      </div>

      {/* Barra de Herramientas Modular (Tabs: FX, Tipografía, Stickers) */}
      <div className="space-y-2 bg-[#161B22] rounded-2xl border border-slate-800 p-3 shadow-md">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setActiveTab('fx')}
              className={`px-3 py-1 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'fx'
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              FX Especiales
            </button>
            <button
              onClick={() => setActiveTab('typo')}
              className={`px-3 py-1 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'typo'
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Tipografía
            </button>
            <button
              onClick={() => setActiveTab('stickers')}
              className={`px-3 py-1 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'stickers'
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Stickers & CTA
            </button>
          </div>
          <span className="text-[10px] text-slate-400 font-mono">
            {activeTab === 'fx' ? `${FX_FILTERS.length} Filtros` : activeTab === 'typo' ? '4 Fuentes' : '4 Stickers'}
          </span>
        </div>

        {/* Panel 1: FX Especiales */}
        {activeTab === 'fx' && (
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
            {FX_FILTERS.map((fx) => (
              <button
                key={fx.id}
                onClick={() => {
                  setActiveFilterId(fx.id);
                  onShowToast(`Filtro "${fx.name}" aplicado`);
                }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 transition-all ${
                  activeFilterId === fx.id
                    ? 'bg-amber-500/20 border border-amber-500/50 text-amber-300 shadow-sm'
                    : 'bg-[#1E2633] border border-slate-800 text-slate-300 hover:border-slate-600'
                }`}
              >
                <span>{fx.icon}</span>
                <span>{fx.name}</span>
              </button>
            ))}
          </div>
        )}

        {/* Panel 2: Tipografía & Tamaño */}
        {activeTab === 'typo' && (
          <div className="space-y-2.5 py-1">
            <div className="grid grid-cols-4 gap-1.5">
              <button
                onClick={() => setActiveFont('font-syne')}
                className={`py-1.5 px-2 rounded-xl text-xs font-syne font-bold transition-all ${
                  activeFont === 'font-syne'
                    ? 'bg-purple-600/30 border border-purple-400 text-purple-200'
                    : 'bg-[#1E2633] text-slate-400 border border-slate-800'
                }`}
              >
                Syne
              </button>
              <button
                onClick={() => setActiveFont('font-bebas')}
                className={`py-1.5 px-2 rounded-xl text-xs font-bebas tracking-wide transition-all ${
                  activeFont === 'font-bebas'
                    ? 'bg-purple-600/30 border border-purple-400 text-purple-200'
                    : 'bg-[#1E2633] text-slate-400 border border-slate-800'
                }`}
              >
                Bebas
              </button>
              <button
                onClick={() => setActiveFont('font-playfair')}
                className={`py-1.5 px-2 rounded-xl text-xs font-playfair italic transition-all ${
                  activeFont === 'font-playfair'
                    ? 'bg-purple-600/30 border border-purple-400 text-purple-200'
                    : 'bg-[#1E2633] text-slate-400 border border-slate-800'
                }`}
              >
                Playfair
              </button>
              <button
                onClick={() => setActiveFont('font-sans')}
                className={`py-1.5 px-2 rounded-xl text-xs font-sans transition-all ${
                  activeFont === 'font-sans'
                    ? 'bg-purple-600/30 border border-purple-400 text-purple-200'
                    : 'bg-[#1E2633] text-slate-400 border border-slate-800'
                }`}
              >
                Inter
              </button>
            </div>

            <div className="flex items-center gap-3">
              <span className="text-[10px] text-slate-400 font-mono w-16">Tamaño: {fontSize}px</span>
              <input
                type="range"
                min="16"
                max="32"
                value={fontSize}
                onChange={(e) => setFontSize(Number(e.target.value))}
                className="flex-1 accent-purple-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>
          </div>
        )}

        {/* Panel 3: Stickers & CTA */}
        {activeTab === 'stickers' && (
          <div className="grid grid-cols-2 gap-2 py-1">
            <button
              onClick={() => {
                setCtaLabel('Pedir por WhatsApp');
                setBadgeText('2X1 HOY');
                onShowToast('Sticker WhatsApp 2x1 activado');
              }}
              className="p-2 rounded-xl bg-[#1E2633] border border-emerald-500/30 text-emerald-300 text-left flex items-center gap-2"
            >
              <span>💬</span>
              <div className="text-[11px]">
                <div className="font-bold">Pedir WhatsApp</div>
                <div className="text-[9px] text-slate-400">Badge 2x1</div>
              </div>
            </button>
            <button
              onClick={() => {
                setCtaLabel('Comenta CROISSANT');
                setBadgeText('🔥 FOODPORN');
                onShowToast('Sticker Comentarios Virales activado');
              }}
              className="p-2 rounded-xl bg-[#1E2633] border border-rose-500/30 text-rose-300 text-left flex items-center gap-2"
            >
              <span>👇</span>
              <div className="text-[11px]">
                <div className="font-bold">Comentar Palabra</div>
                <div className="text-[9px] text-slate-400">Algoritmo Reels</div>
              </div>
            </button>
          </div>
        )}
      </div>

      {/* Chat IA de Edición Avanzada Proactivo */}
      <div className="space-y-2.5 bg-[#12161E] rounded-2xl border border-slate-800 p-3.5 shadow-sm">
        <div className="flex items-start gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-purple-600 to-rose-500 flex items-center justify-center text-xs shrink-0 shadow-md">
            ✨
          </div>
          <div className="space-y-1 flex-1">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white">Copilot IA Creativo</span>
              <span className="text-[9px] text-[#4edea3] font-mono">Online</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed bg-[#161B22] rounded-xl p-2.5 border border-slate-800">
              {aiMessage}
            </p>
          </div>
        </div>

        {/* Quick Prompt Pills a 1 Toque */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
          <button
            onClick={() => handleApplyQuickPrompt('Hacerlo más elegante')}
            className="px-2.5 py-1 rounded-full text-[10px] font-medium bg-[#1E2633] border border-purple-500/30 text-purple-300 hover:bg-purple-500/20 shrink-0 transition-colors"
          >
            ✨ Más elegante
          </button>
          <button
            onClick={() => handleApplyQuickPrompt('Fuente Display')}
            className="px-2.5 py-1 rounded-full text-[10px] font-medium bg-[#1E2633] border border-slate-700 text-slate-300 hover:text-white shrink-0 transition-colors"
          >
            🔤 Fuente Display
          </button>
          <button
            onClick={() => handleApplyQuickPrompt('Oferta urgente')}
            className="px-2.5 py-1 rounded-full text-[10px] font-medium bg-[#1E2633] border border-rose-500/30 text-rose-300 hover:bg-rose-500/20 shrink-0 transition-colors"
          >
            🔥 Oferta urgente
          </button>
          <button
            onClick={() => handleApplyQuickPrompt('Resaltar hojaldre')}
            className="px-2.5 py-1 rounded-full text-[10px] font-medium bg-[#1E2633] border border-amber-500/30 text-amber-300 hover:bg-amber-500/20 shrink-0 transition-colors"
          >
            🥐 Resaltar hojaldre
          </button>
        </div>

        {/* Input de Chat */}
        <div className="flex items-center gap-1.5 pt-1">
          <button
            onClick={() => onShowToast('Imagen de producto seleccionada')}
            className="p-2 rounded-xl bg-[#161B22] border border-slate-800 text-slate-400 hover:text-white"
            title="Adjuntar imagen"
          >
            <span className="material-symbols-outlined text-[16px]">add_photo_alternate</span>
          </button>
          <input
            value={aiInput}
            onChange={(e) => setAiInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && aiInput.trim()) {
                executeAiEdit(aiInput);
                setAiInput('');
              }
            }}
            placeholder="Ej: Haz el texto más irresistible y corto..."
            className="flex-1 bg-[#161B22] border border-slate-700/80 rounded-xl px-3 py-2 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-purple-500"
          />
          <button
            onClick={() => {
              if (aiInput.trim()) {
                executeAiEdit(aiInput);
                setAiInput('');
              } else {
                executeAiEdit('Hacerlo más elegante');
              }
            }}
            className="px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold shadow-md active:scale-95 transition-all flex items-center gap-1"
          >
            <span>Pedir</span>
          </button>
        </div>
      </div>

      {/* Sticky Bottom Bar de Aprobación y n8n Dispatch */}
      <aside aria-label="Acciones de publicación" className="fixed bottom-0 inset-x-0 max-w-md mx-auto z-50 p-3 bg-[#0D1117]/95 backdrop-blur-lg border-t border-slate-800 shadow-[0_-8px_20px_rgba(0,0,0,0.5)]">
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-[10px] text-slate-400 px-1 font-mono">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block animate-ping"></span>
              Orquestador n8n listo (3 Canales)
            </span>
            <span className="text-emerald-400 font-semibold">1-Tap Publish</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onOpenQuickPublish}
              className="p-2.5 rounded-xl bg-[#1E2633] hover:bg-slate-800 text-slate-300 border border-slate-700 transition-colors flex items-center justify-center shrink-0"
              title="Guardar Borrador"
            >
              <span className="material-symbols-outlined text-[18px]">bookmark</span>
            </button>

            <button
              onClick={handleDispatchN8n}
              disabled={isDispatching}
              className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-white font-bold text-xs shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
            >
              {isDispatching ? (
                <>
                  <span className="material-symbols-outlined text-[16px] animate-spin">refresh</span>
                  <span>Enviando al flujo n8n...</span>
                </>
              ) : (
                <>
                  <span className="material-symbols-outlined text-[16px] animate-bounce">bolt</span>
                  <span>Aprobar y Distribuir vía n8n</span>
                </>
              )}
            </button>
          </div>
        </div>
      </aside>
    </div>
  );
};
