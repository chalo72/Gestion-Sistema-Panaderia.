import React from 'react';

interface ToastNotificationProps {
  message: string | null;
  type?: 'success' | 'info' | 'ai';
  onClose: () => void;
}

export const ToastNotification: React.FC<ToastNotificationProps> = ({
  message,
  type = 'success',
  onClose
}) => {
  if (!message) return null;

  return (
    <div className="fixed bottom-20 left-4 right-4 z-50 max-w-md mx-auto bg-[#1c2028]/95 border border-[#4edea3]/40 text-[#dfe2ee] px-4 py-3 rounded-2xl shadow-2xl flex items-center justify-between backdrop-blur-xl transition-all duration-300 transform translate-y-0 animate-in fade-in slide-in-from-bottom-2">
      <div className="flex items-center gap-2.5 min-w-0">
        <span className="material-symbols-outlined text-[#4edea3] text-[22px]">
          {type === 'ai' ? 'auto_awesome' : 'check_circle'}
        </span>
        <span className="text-xs font-medium truncate text-slate-200">
          {message}
        </span>
      </div>
      <button
        onClick={onClose}
        className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors ml-2"
        aria-label="Cerrar notificación"
      >
        <span className="material-symbols-outlined text-[16px]">close</span>
      </button>
    </div>
  );
};
