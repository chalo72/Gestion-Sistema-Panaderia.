import React from 'react';
import { BrandProfile, ScreenView } from '../types';
import { PILARES_ESTRATEGICOS } from '../data';

interface EstrategiaViewProps {
  activeBrand: BrandProfile;
  onChangeView: (view: ScreenView) => void;
  onShowToast: (msg: string) => void;
}

export const EstrategiaView: React.FC<EstrategiaViewProps> = ({
  activeBrand,
  onChangeView,
  onShowToast
}) => {
  return (
    <div className="flex flex-col w-full gap-4 pb-20 animate-in fade-in duration-300">
      {/* Context Banner & Progress Ring Matrix */}
      <section className="flex flex-col rounded-2xl bg-[#262a33]/90 p-4 shadow-xl backdrop-blur-xl relative overflow-hidden border border-white/5">
        {/* Ambient aura */}
        <div className="absolute -right-8 -top-8 w-36 h-36 rounded-full bg-purple-600/20 blur-2xl pointer-events-none"></div>
        <div className="absolute -left-8 -bottom-8 w-32 h-32 rounded-full bg-emerald-500/20 blur-2xl pointer-events-none"></div>

        <div className="flex items-start justify-between gap-2 relative z-10">
          <div className="flex flex-col min-w-0">
            <div className="flex items-center gap-1.5 mb-1">
              <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-emerald-500/15 text-[#4edea3] font-mono text-[9px] uppercase tracking-wider font-semibold border border-emerald-500/20">
                Estrategia Q1 Activa
              </span>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#1c2028] text-slate-300 font-mono text-[9px]">
                <span className="material-symbols-outlined text-[12px] text-cyan-400">bolt</span> Sincronizado
              </span>
            </div>
            <h1 className="font-display text-xl font-bold text-white truncate">
              Crecimiento Omnicanal
            </h1>
            <p className="text-xs text-slate-400 truncate">
              {activeBrand.name} · {activeBrand.activeStrategy}
            </p>
          </div>

          <button
            onClick={() => onShowToast('🚀 Sprint IA activado: Generando 6 publicaciones y 2 promos flash')}
            className="shrink-0 min-h-[44px] px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#571bc1] to-[#8B5CF6] hover:from-[#6520e0] hover:to-[#9c75f7] text-white flex items-center gap-1.5 shadow-md active:scale-95 transition-all border border-purple-400/30"
          >
            <span className="material-symbols-outlined text-[18px]">auto_awesome</span>
            <span className="font-mono text-xs font-semibold text-purple-100">Sprint IA</span>
          </button>
        </div>

        {/* Balance Spectrum Gauge */}
        <div className="mt-4 pt-1 flex flex-col gap-1.5 relative z-10">
          <div className="flex items-center justify-between font-mono text-[10px] text-slate-400">
            <span>Balance de Enfoque Q1</span>
            <span className="text-[#4edea3] font-semibold">100% Calibrado</span>
          </div>

          {/* Segmented Track */}
          <div className="w-full h-2.5 rounded-full bg-[#0a0e16] flex overflow-hidden p-0.5 gap-0.5 shadow-inner border border-white/5">
            <div className="h-full rounded-full bg-[#4edea3]" style={{ width: '25%' }} title="Brand: 25%"></div>
            <div className="h-full rounded-full bg-[#d0bcff]" style={{ width: '35%' }} title="Engagement: 35%"></div>
            <div className="h-full rounded-full bg-[#4cd7f6]" style={{ width: '15%' }} title="Community: 15%"></div>
            <div className="h-full rounded-full bg-[#10b981]" style={{ width: '25%' }} title="Sales: 25%"></div>
          </div>

          {/* Balance Legend */}
          <div className="grid grid-cols-4 gap-1 pt-1 text-center font-mono text-[9px]">
            <div className="flex flex-col items-center">
              <span className="text-[#4edea3] font-bold">25%</span>
              <span className="text-slate-400 uppercase text-[8.5px] tracking-tight">Brand</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-[#d0bcff] font-bold">35%</span>
              <span className="text-slate-400 uppercase text-[8.5px] tracking-tight">Interacción</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-[#4cd7f6] font-bold">15%</span>
              <span className="text-slate-400 uppercase text-[8.5px] tracking-tight">Comunidad</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-[#10b981] font-bold">25%</span>
              <span className="text-slate-400 uppercase text-[8.5px] tracking-tight">Ventas</span>
            </div>
          </div>
        </div>
      </section>

      {/* Copilot Estratégico AI Context Bar (HUD Alert) */}
      <section className="rounded-2xl bg-[#1c2028]/95 p-4 shadow-lg backdrop-blur-xl relative overflow-hidden border border-purple-500/30">
        <div className="flex items-start gap-3">
          <div className="w-8 h-8 rounded-xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-purple-300 shrink-0 mt-0.5">
            <span className="material-symbols-outlined text-[20px]">neurology</span>
          </div>
          <div className="flex flex-col flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <span className="font-display text-xs font-semibold text-purple-200">Copilot Estratégico</span>
              <span className="font-mono text-[8px] px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 font-bold border border-purple-500/30">
                SUGERENCIA EN VIVO
              </span>
            </div>
            <p className="text-xs text-slate-200 leading-relaxed">
              “Tu pilar de <span className="text-purple-300 font-medium">Interacción</span> supera la meta, pero <span className="text-emerald-400 font-medium">Conversión</span> requiere 2 stories flash hoy a las 18:00 para cerrar pedidos de San Valentín.”
            </p>

            {/* Quick AI Action Pills */}
            <div className="flex flex-wrap gap-1.5 mt-3">
              <button
                onClick={() => onChangeView('studio-canvas')}
                className="px-2.5 py-1.5 rounded-lg bg-emerald-500/20 border border-emerald-500/30 text-[#4edea3] hover:bg-emerald-500/30 transition-colors font-mono text-[10px] flex items-center gap-1 active:scale-95 font-semibold"
              >
                <span className="material-symbols-outlined text-[13px]">bolt</span>
                <span>Crear Promo Flash Ahora</span>
              </button>
              <button
                onClick={() => onChangeView('calendario')}
                className="px-2.5 py-1.5 rounded-lg bg-[#31353e] hover:bg-[#3d424e] text-slate-300 hover:text-white transition-colors font-mono text-[10px] flex items-center gap-1 active:scale-95"
              >
                <span className="material-symbols-outlined text-[13px]">tune</span>
                <span>Equilibrar Calendario</span>
              </button>
              <button
                onClick={() => onChangeView('hub-central')}
                className="px-2.5 py-1.5 rounded-lg bg-[#31353e] hover:bg-[#3d424e] text-slate-300 hover:text-white transition-colors font-mono text-[10px] flex items-center gap-1 active:scale-95"
              >
                <span className="material-symbols-outlined text-[13px]">grid_view</span>
                <span>Matriz de Formatos</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Los 4 Pilares Estratégicos Bento Stack */}
      <section className="flex flex-col gap-3">
        <div className="flex items-center justify-between px-0.5">
          <div className="flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[#4edea3] text-[18px]">account_tree</span>
            <h2 className="font-display text-sm font-bold text-white">Pilares Estratégicos 360°</h2>
          </div>
          <span className="font-mono text-xs text-slate-400">4 de 4 Activos</span>
        </div>

        {/* Pilar 1: Presencia de Marca */}
        <article className="flex flex-col rounded-2xl bg-[#181c24] p-3.5 shadow-md gap-2 border border-white/5 hover:border-emerald-500/30 transition-all">
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-emerald-500/10 border border-emerald-500/25 flex items-center justify-center text-[#4edea3]">
                <span className="material-symbols-outlined text-[16px]">verified</span>
              </div>
              <div>
                <h3 className="font-display text-xs font-bold text-white">1. Presencia de Marca</h3>
                <span className="font-mono text-[10px] text-slate-400">Brand Authority & Estética Visual</span>
              </div>
            </div>
            <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 text-[#4edea3] font-mono text-[10px] font-semibold flex items-center gap-1 border border-emerald-500/20">
              <span className="w-1.5 h-1.5 rounded-full bg-[#4edea3] animate-pulse"></span>
              Activo
            </span>
          </div>

          <div className="relative w-full h-28 rounded-xl overflow-hidden mt-1 shadow-inner border border-white/5">
            <div
              className="bg-cover bg-center w-full h-full scale-[1.02] hover:scale-105 transition-transform duration-500"
              style={{ backgroundImage: `url('${PILARES_ESTRATEGICOS[0].image}')` }}
            ></div>
            <div className="absolute inset-0 bg-gradient-to-t from-[#0a0e16]/95 via-[#0a0e16]/30 to-transparent flex items-end p-2.5 justify-between">
              <span className="font-mono text-xs text-white flex items-center gap-1">
                <span className="material-symbols-outlined text-[15px] text-[#4edea3]">play_circle</span> 4 piezas programadas
              </span>
              <span className="font-mono text-[10px] px-2 py-0.5 rounded bg-[#262a33]/90 text-[#4edea3] font-semibold border border-white/10">
                Reels 4K
              </span>
            </div>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed mt-0.5">
            {PILARES_ESTRATEGICOS[0].description}
          </p>

          <div className="mt-1 pt-1.5 flex items-center justify-between bg-[#0a0e16]/70 px-3 py-1.5 rounded-xl border border-white/5">
            <div className="flex items-center gap-1 font-mono text-[10px] text-slate-400">
              <span className="material-symbols-outlined text-[14px] text-[#4edea3]">visibility</span>
              <span>KPI Meta:</span>
            </div>
            <div className="flex items-baseline gap-1 font-mono text-xs">
              <span className="text-[#4edea3] font-bold">+45K</span>
              <span className="text-slate-400 text-[10px]">reproducciones (78% completado)</span>
            </div>
          </div>
        </article>

        {/* Pilar 2: Aumento de Interacción */}
        <article className="flex flex-col rounded-2xl bg-[#181c24] p-3.5 shadow-md gap-2 border border-white/5 hover:border-purple-500/30 transition-all">
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-purple-500/15 border border-purple-500/25 flex items-center justify-center text-purple-300">
                <span className="material-symbols-outlined text-[16px]">forum</span>
              </div>
              <div>
                <h3 className="font-display text-xs font-bold text-white">2. Aumento de Interacción</h3>
                <span className="font-mono text-[10px] text-slate-400">Engagement, Retención & Viralidad</span>
              </div>
            </div>
            <span className="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 font-mono text-[10px] font-semibold flex items-center gap-1 border border-purple-500/30">
              <span className="material-symbols-outlined text-[12px]">auto_awesome</span>
              Optimizado IA
            </span>
          </div>

          <div className="relative w-full h-28 rounded-xl overflow-hidden mt-1 shadow-inner border border-white/5">
            <div
              className="bg-cover bg-center w-full h-full scale-[1.02] hover:scale-105 transition-transform duration-500"
              style={{ backgroundImage: `url('${PILARES_ESTRATEGICOS[1].image}')` }}
            ></div>
            <div className="absolute inset-0 bg-gradient-to-t from-[#0a0e16]/95 via-[#0a0e16]/30 to-transparent flex items-end p-2.5 justify-between">
              <span className="font-mono text-xs text-white flex items-center gap-1">
                <span className="material-symbols-outlined text-[15px] text-purple-400">ballot</span> Encuestas de Recetas
              </span>
              <span className="font-mono text-[10px] px-2 py-0.5 rounded bg-[#262a33]/90 text-purple-200 font-semibold border border-white/10">
                TikTok Hooks
              </span>
            </div>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed mt-0.5">
            {PILARES_ESTRATEGICOS[1].description}
          </p>

          <div className="mt-1 pt-1.5 flex items-center justify-between bg-[#0a0e16]/70 px-3 py-1.5 rounded-xl border border-white/5">
            <div className="flex items-center gap-1 font-mono text-[10px] text-slate-400">
              <span className="material-symbols-outlined text-[14px] text-purple-400">query_stats</span>
              <span>KPI Meta:</span>
            </div>
            <div className="flex items-baseline gap-1 font-mono text-xs">
              <span className="text-purple-300 font-bold">8.4%</span>
              <span className="text-[#4edea3] text-[10px] font-semibold flex items-center">
                <span className="material-symbols-outlined text-[12px]">arrow_upward</span> 9.1% actual
              </span>
            </div>
          </div>
        </article>

        {/* Pilar 3: Crecimiento de Comunidad */}
        <article className="flex flex-col rounded-2xl bg-[#181c24] p-3.5 shadow-md gap-2 border border-white/5 hover:border-cyan-500/30 transition-all">
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-cyan-500/15 border border-cyan-500/25 flex items-center justify-center text-cyan-300">
                <span className="material-symbols-outlined text-[16px]">groups</span>
              </div>
              <div>
                <h3 className="font-display text-xs font-bold text-white">3. Crecimiento de Comunidad</h3>
                <span className="font-mono text-[10px] text-slate-400">Retención, Club VIP & Fidelidad Local</span>
              </div>
            </div>
            <span className="px-2 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 font-mono text-[10px] font-semibold flex items-center gap-1 border border-cyan-500/30">
              WhatsApp Activo
            </span>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed mt-0.5">
            {PILARES_ESTRATEGICOS[2].description}
          </p>

          <div className="flex items-center gap-2 pt-1">
            <div className="flex -space-x-2 overflow-hidden py-1">
              <div className="w-7 h-7 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center font-mono text-[#4edea3] text-[10px] font-bold">DP</div>
              <div className="w-7 h-7 rounded-full bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center font-mono text-cyan-300 text-[10px] font-bold">VIP</div>
              <div className="w-7 h-7 rounded-full bg-purple-500/20 border border-purple-500/40 flex items-center justify-center font-mono text-purple-200 text-[10px] font-bold">+99</div>
            </div>
            <span className="font-mono text-xs text-slate-400 truncate">Canal exclusivo con 640 miembros activos</span>
          </div>

          <div className="mt-1 pt-1.5 flex items-center justify-between bg-[#0a0e16]/70 px-3 py-1.5 rounded-xl border border-white/5">
            <div className="flex items-center gap-1 font-mono text-[10px] text-slate-400">
              <span className="material-symbols-outlined text-[14px] text-cyan-400">loyalty</span>
              <span>KPI Meta:</span>
            </div>
            <div className="flex items-baseline gap-1 font-mono text-xs">
              <span className="text-cyan-300 font-bold">+1,200</span>
              <span className="text-slate-400 text-[10px]">miembros leales (64% logrado)</span>
            </div>
          </div>
        </article>

        {/* Pilar 4: Conversión y Ventas */}
        <article className="flex flex-col rounded-2xl bg-[#181c24] p-3.5 shadow-md gap-2 border border-white/5 hover:border-emerald-500/30 transition-all">
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-emerald-500/15 border border-emerald-500/25 flex items-center justify-center text-[#10b981]">
                <span className="material-symbols-outlined text-[16px]">shopping_cart_checkout</span>
              </div>
              <div>
                <h3 className="font-display text-xs font-bold text-white">4. Conversión y Ventas</h3>
                <span className="font-mono text-[10px] text-slate-400">High-Intent Funnel & Escasez Flash</span>
              </div>
            </div>
            <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-[#4edea3] font-mono text-[10px] font-semibold flex items-center gap-1 border border-emerald-500/30">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
              n8n Flow ON
            </span>
          </div>

          <div className="rounded-xl bg-[#0a0e16] p-3 flex flex-col gap-1.5 mt-1 border border-white/5">
            <div className="flex items-center justify-between">
              <span className="font-mono text-xs text-white font-semibold flex items-center gap-1">
                <span className="material-symbols-outlined text-[14px] text-emerald-400">local_offer</span> Combo Desayuno Hojaldre 2x1
              </span>
              <span className="font-mono text-[10px] px-2 py-0.5 rounded bg-emerald-500 text-black font-bold">HOY 18:00</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Disparador automatizado por WhatsApp API + webhook de pedidos urgentes hacia cocina.
            </p>
          </div>

          <div className="mt-1 pt-1.5 flex items-center justify-between bg-[#0a0e16]/70 px-3 py-1.5 rounded-xl border border-white/5">
            <div className="flex items-center gap-1 font-mono text-[10px] text-slate-400">
              <span className="material-symbols-outlined text-[14px] text-emerald-400">payments</span>
              <span>KPI Meta:</span>
            </div>
            <div className="flex items-baseline gap-1 font-mono text-xs">
              <span className="text-emerald-400 font-bold">$3,450 USD</span>
              <span className="text-slate-400 text-[10px]">($2,180 atribuido a n8n)</span>
            </div>
          </div>
        </article>
      </section>

      {/* Matriz de Canales Recomendados */}
      <section className="flex flex-col gap-2.5">
        <div className="flex items-center justify-between px-0.5">
          <h2 className="font-display text-sm font-bold text-white">Distribución por Canales</h2>
          <span className="font-mono text-[10px] text-slate-400">Sincronización 360°</span>
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          {/* Instagram */}
          <div className="rounded-2xl bg-[#181c24] p-3 flex flex-col gap-1.5 shadow-sm border border-white/5">
            <div className="flex items-center justify-between">
              <span className="font-display text-xs font-semibold text-white flex items-center gap-1.5">
                <span className="material-symbols-outlined text-[16px] text-pink-400">camera</span> Instagram
              </span>
              <span className="font-mono text-[11px] text-[#4edea3] font-bold">45%</span>
            </div>
            <span className="font-mono text-[10px] text-slate-400">Objetivo:</span>
            <span className="px-2 py-0.5 rounded-lg bg-[#1c2028] text-slate-200 font-mono text-[10px] truncate">
              Estética & Engagement
            </span>
            <span className="font-mono text-[10px] text-slate-400 mt-0.5">5 posts / sem + Stories</span>
          </div>

          {/* TikTok */}
          <div className="rounded-2xl bg-[#181c24] p-3 flex flex-col gap-1.5 shadow-sm border border-white/5">
            <div className="flex items-center justify-between">
              <span className="font-display text-xs font-semibold text-white flex items-center gap-1.5">
                <span className="material-symbols-outlined text-[16px] text-cyan-400">music_note</span> TikTok
              </span>
              <span className="font-mono text-[11px] text-purple-300 font-bold">25%</span>
            </div>
            <span className="font-mono text-[10px] text-slate-400">Objetivo:</span>
            <span className="px-2 py-0.5 rounded-lg bg-[#1c2028] text-slate-200 font-mono text-[10px] truncate">
              Alcance Orgánico
            </span>
            <span className="font-mono text-[10px] text-slate-400 mt-0.5">3 videos rápidos / sem</span>
          </div>

          {/* WhatsApp */}
          <div className="rounded-2xl bg-[#181c24] p-3 flex flex-col gap-1.5 shadow-sm border border-white/5">
            <div className="flex items-center justify-between">
              <span className="font-display text-xs font-semibold text-white flex items-center gap-1.5">
                <span className="material-symbols-outlined text-[16px] text-emerald-400">chat</span> WhatsApp
              </span>
              <span className="font-mono text-[11px] text-emerald-400 font-bold">20%</span>
            </div>
            <span className="font-mono text-[10px] text-slate-400">Objetivo:</span>
            <span className="px-2 py-0.5 rounded-lg bg-[#1c2028] text-slate-200 font-mono text-[10px] truncate">
              Cierre & Reorden VIP
            </span>
            <span className="font-mono text-[10px] text-slate-400 mt-0.5">2 broadcast flash / sem</span>
          </div>

          {/* Facebook */}
          <div className="rounded-2xl bg-[#181c24] p-3 flex flex-col gap-1.5 shadow-sm border border-white/5">
            <div className="flex items-center justify-between">
              <span className="font-display text-xs font-semibold text-white flex items-center gap-1.5">
                <span className="material-symbols-outlined text-[16px] text-slate-400">public</span> Facebook
              </span>
              <span className="font-mono text-[11px] text-slate-400 font-bold">10%</span>
            </div>
            <span className="font-mono text-[10px] text-slate-400">Objetivo:</span>
            <span className="px-2 py-0.5 rounded-lg bg-[#1c2028] text-slate-200 font-mono text-[10px] truncate">
              Comunidad Barrial
            </span>
            <span className="font-mono text-[10px] text-slate-400 mt-0.5">Eventos & Horarios</span>
          </div>
        </div>
      </section>

      {/* Cockpit Motor n8n & Action Tray */}
      <section className="flex flex-col gap-2 pt-1 mb-2">
        <div className="p-4 rounded-2xl bg-[#262a33]/90 border border-emerald-500/30 backdrop-blur-xl flex flex-col gap-3 shadow-2xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#4edea3] animate-ping"></span>
              <span className="font-mono text-xs text-white font-semibold">Motor n8n Conectado</span>
            </div>
            <span className="font-mono text-xs text-[#4edea3] font-bold">Ciclo: Sprint #06</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onShowToast('Sprint semanal sincronizado con n8n y calendario de Dulce Placer.')}
              className="min-h-[44px] flex-1 rounded-xl bg-[#31353e] hover:bg-[#3d424e] text-white px-3 py-2 flex items-center justify-center gap-1.5 active:scale-95 transition-all text-xs font-semibold"
            >
              <span className="material-symbols-outlined text-[18px] text-purple-300">psychology</span>
              <span className="truncate">Planificar Sprint IA</span>
            </button>

            <button
              onClick={() => {
                onShowToast('¡Campaña 360° en vivo en Instagram, TikTok y WhatsApp!');
              }}
              className="min-h-[44px] flex-1 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-black px-3 py-2 flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-500/25 active:scale-95 transition-all text-xs font-bold font-display"
            >
              <span className="material-symbols-outlined text-[18px]">rocket_launch</span>
              <span className="truncate">Lanzar Campaña 360°</span>
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
