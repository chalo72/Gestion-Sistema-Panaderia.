import React, { useState } from 'react';
import { ScreenView } from '../types';
import { HUB_MODULES } from '../data';

interface HubCentralViewProps {
  onChangeView: (view: ScreenView) => void;
  onShowToast: (msg: string) => void;
  onOpenQuickPublish: () => void;
}

export const HubCentralView: React.FC<HubCentralViewProps> = ({
  onChangeView,
  onShowToast,
  onOpenQuickPublish
}) => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [activeCategory, setActiveCategory] = useState<'all' | 'estrategia' | 'creativo' | 'growth'>('all');

  const filteredModules = HUB_MODULES.filter((mod) => {
    const matchesCategory = activeCategory === 'all' || mod.category === activeCategory;
    const matchesSearch =
      mod.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      mod.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      mod.tags.some((t) => t.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="flex flex-col w-full gap-4 pb-28 animate-in fade-in duration-300">
      {/* Header Banner */}
      <section className="bg-gradient-to-br from-[#1c2028] via-[#161b24] to-[#0f131c] p-4 rounded-2xl border border-white/10 shadow-xl space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-xl bg-purple-600/20 border border-purple-500/40 text-purple-300 flex items-center justify-center font-bold">
              <span className="material-symbols-outlined text-[20px]">grid_view</span>
            </span>
            <div>
              <span className="text-[10px] font-mono text-purple-300 uppercase font-bold tracking-wider">
                Ecosistema Omnicanal
              </span>
              <h1 className="font-display text-base font-bold text-white leading-tight">
                Menú Central del Ecosistema
              </h1>
            </div>
          </div>
          <button
            onClick={onOpenQuickPublish}
            className="px-2.5 py-1 rounded-xl bg-[#4edea3] text-black font-mono text-[10px] font-bold flex items-center gap-1 shadow-md active:scale-95"
          >
            <span className="material-symbols-outlined text-[14px]">bolt</span>
            <span>Flash</span>
          </button>
        </div>

        <p className="text-xs text-slate-400 leading-relaxed">
          12 Módulos Especializados en Marketing Omnicanal, Creación con IA y Escalabilidad 10X.
        </p>

        {/* Search Input */}
        <div className="relative pt-1">
          <span className="material-symbols-outlined absolute left-3 top-3.5 text-slate-400 text-[18px]">
            search
          </span>
          <input
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Buscar módulo, keyword o herramienta..."
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-[#0a0e16] border border-slate-700 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-[#4edea3]"
          />
        </div>
      </section>

      {/* Category Pills */}
      <section className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
        <button
          onClick={() => setActiveCategory('all')}
          className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
            activeCategory === 'all'
              ? 'bg-[#4edea3] text-black font-bold shadow-sm'
              : 'bg-[#181c24] text-slate-400 hover:text-white border border-white/5'
          }`}
        >
          Todos ({HUB_MODULES.length})
        </button>
        <button
          onClick={() => setActiveCategory('estrategia')}
          className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
            activeCategory === 'estrategia'
              ? 'bg-purple-600 text-white font-bold shadow-sm'
              : 'bg-[#181c24] text-slate-400 hover:text-white border border-white/5'
          }`}
        >
          Estrategia & Embudo (3)
        </button>
        <button
          onClick={() => setActiveCategory('creativo')}
          className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
            activeCategory === 'creativo'
              ? 'bg-cyan-500 text-black font-bold shadow-sm'
              : 'bg-[#181c24] text-slate-400 hover:text-white border border-white/5'
          }`}
        >
          Canvas Creativo & FX (5)
        </button>
        <button
          onClick={() => setActiveCategory('growth')}
          className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
            activeCategory === 'growth'
              ? 'bg-emerald-500 text-black font-bold shadow-sm'
              : 'bg-[#181c24] text-slate-400 hover:text-white border border-white/5'
          }`}
        >
          Crecimiento & 10X (4)
        </button>
      </section>

      {/* Modules Grid */}
      <section className="space-y-3">
        {filteredModules.map((mod) => (
          <article
            key={mod.id}
            className="bg-[#181c24] rounded-2xl p-4 border border-white/5 flex flex-col gap-2.5 shadow-md hover:border-slate-600 transition-all group"
          >
            <div className="flex items-center justify-between">
              <span className="text-[9px] font-mono px-2 py-0.5 rounded-md bg-[#262a33] text-slate-300 font-semibold uppercase">
                {mod.badge}
              </span>
              <span className="text-[9px] font-mono text-[#4edea3] bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                {mod.statusBadge}
              </span>
            </div>

            <div>
              <h3 className="font-display text-sm font-bold text-white group-hover:text-[#4edea3] transition-colors">
                {mod.title}
              </h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                {mod.description}
              </p>
            </div>

            {/* Tag Pills */}
            <div className="flex flex-wrap gap-1.5 pt-0.5">
              {mod.tags.map((tag, idx) => (
                <span
                  key={idx}
                  className="text-[9.5px] font-mono px-2 py-0.5 rounded-md bg-[#111620] text-slate-300 border border-white/5"
                >
                  {tag}
                </span>
              ))}
            </div>

            <div className="pt-2 border-t border-white/5 flex items-center justify-between">
              <span className="text-[10px] text-slate-400 font-mono">
                Pantalla vinculada: {mod.targetScreen}
              </span>
              <button
                onClick={() => {
                  onChangeView(mod.targetScreen);
                  onShowToast(`Navegando a ${mod.title}`);
                }}
                className="py-1.5 px-3 rounded-xl bg-[#262a33] hover:bg-[#343a46] text-[#4edea3] text-xs font-mono font-bold flex items-center gap-1 active:scale-95 transition-all"
              >
                <span>Abrir Pantalla</span>
                <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
              </button>
            </div>
          </article>
        ))}
      </section>
    </div>
  );
};
