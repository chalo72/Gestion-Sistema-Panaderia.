import React, { useState } from 'react';
import { BrandProfile, ScreenView } from '../types';

interface TopHeaderProps {
  activeBrand: BrandProfile;
  brands: BrandProfile[];
  onSelectBrand: (brand: BrandProfile) => void;
  currentView: ScreenView;
  onChangeView: (view: ScreenView) => void;
  onOpenQuickPublish: () => void;
  isMobileDeviceFrame: boolean;
  onToggleDeviceFrame: () => void;
  onShowToast: (msg: string) => void;
}

export const TopHeader: React.FC<TopHeaderProps> = ({
  activeBrand,
  brands,
  onSelectBrand,
  currentView,
  onChangeView,
  onOpenQuickPublish,
  isMobileDeviceFrame,
  onToggleDeviceFrame,
  onShowToast
}) => {
  const [showBrandDropdown, setShowBrandDropdown] = useState(false);

  return (
    <header className="sticky top-0 w-full z-40 bg-[#0f131c]/90 backdrop-blur-xl border-b border-[#262a33]/80 shadow-[0_2px_12px_rgba(0,0,0,0.45)]">
      <div className="h-16 px-4 flex items-center justify-between gap-2 max-w-7xl mx-auto">
        {/* Left: Brand Selector Dropdown */}
        <div className="relative">
          <button
            onClick={() => setShowBrandDropdown(!showBrandDropdown)}
            aria-label="Seleccionar Marca"
            className="min-h-[44px] px-3 py-1.5 rounded-xl bg-[#1c2028] hover:bg-[#262a33] border border-white/5 flex items-center gap-2 text-left transition-all active:scale-98 shadow-sm"
          >
            <div className="w-8 h-8 rounded-lg bg-[#0f131c] flex items-center justify-center text-lg border border-white/5">
              {activeBrand.icon}
            </div>
            <div className="flex flex-col">
              <div className="flex items-center gap-1">
                <span className="font-display text-xs font-semibold text-white max-w-[140px] truncate">
                  {activeBrand.name}
                </span>
                <span className="material-symbols-outlined text-[14px] text-slate-400">
                  unfold_more
                </span>
              </div>
              <span className="font-mono text-[9px] uppercase tracking-wider text-[#4edea3] flex items-center gap-1 font-semibold">
                <span className="w-1.5 h-1.5 rounded-full bg-[#4edea3]"></span>
                {activeBrand.badge}
              </span>
            </div>
          </button>

          {/* Brand Dropdown Menu */}
          {showBrandDropdown && (
            <div className="absolute left-0 top-full mt-2 w-64 bg-[#181c24] border border-slate-700/60 rounded-2xl p-2 shadow-2xl z-50 animate-in fade-in slide-in-from-top-2">
              <div className="px-2 py-1 text-[10px] uppercase font-mono tracking-wider text-slate-400">
                Selecciona Cuenta Activa
              </div>
              <div className="space-y-1 mt-1">
                {brands.map((b) => (
                  <button
                    key={b.id}
                    onClick={() => {
                      onSelectBrand(b);
                      setShowBrandDropdown(false);
                      onShowToast(`Cambiaste a la marca: ${b.name}`);
                    }}
                    className={`w-full flex items-center justify-between p-2 rounded-xl text-left transition-all ${
                      b.id === activeBrand.id
                        ? 'bg-emerald-500/15 text-[#4edea3] border border-emerald-500/30'
                        : 'hover:bg-slate-800 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-base">{b.icon}</span>
                      <div>
                        <div className="text-xs font-bold text-white">{b.name}</div>
                        <div className="text-[10px] text-slate-400">{b.category}</div>
                      </div>
                    </div>
                    {b.id === activeBrand.id && (
                      <span className="material-symbols-outlined text-[16px] text-[#4edea3]">
                        check
                      </span>
                    )}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Center: Module / Screen Switcher Shortcut on Desktop/Tablet */}
        <div className="hidden md:flex items-center gap-1 bg-[#181c24] p-1 rounded-xl border border-slate-800/80">
          <button
            onClick={() => onChangeView('estrategia')}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium flex items-center gap-1 transition-all ${
              currentView === 'estrategia'
                ? 'bg-[#262a33] text-[#4edea3] font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="material-symbols-outlined text-[15px]">hub</span>
            <span>Estrategia</span>
          </button>
          <button
            onClick={() => onChangeView('studio-canvas')}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium flex items-center gap-1 transition-all ${
              currentView === 'studio-canvas'
                ? 'bg-[#262a33] text-[#4edea3] font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="material-symbols-outlined text-[15px]">draw</span>
            <span>Studio Canvas</span>
          </button>
          <button
            onClick={() => onChangeView('calendario')}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium flex items-center gap-1 transition-all ${
              currentView === 'calendario'
                ? 'bg-[#262a33] text-[#4edea3] font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="material-symbols-outlined text-[15px]">calendar_month</span>
            <span>Parrilla</span>
          </button>
          <button
            onClick={() => onChangeView('roadmap')}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium flex items-center gap-1 transition-all ${
              currentView === 'roadmap'
                ? 'bg-[#262a33] text-[#4edea3] font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="material-symbols-outlined text-[15px]">monitoring</span>
            <span>Roadmap 10X</span>
          </button>
          <button
            onClick={() => onChangeView('asistente-4pasos')}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium flex items-center gap-1 transition-all ${
              currentView === 'asistente-4pasos'
                ? 'bg-[#262a33] text-[#4edea3] font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="material-symbols-outlined text-[15px]">checklist</span>
            <span>Asistente 4 Pasos</span>
          </button>
          <button
            onClick={() => onChangeView('hub-central')}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium flex items-center gap-1 transition-all ${
              currentView === 'hub-central'
                ? 'bg-emerald-500/20 text-[#4edea3] font-semibold shadow-sm border border-emerald-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="material-symbols-outlined text-[15px]">grid_view</span>
            <span>Hub Central</span>
          </button>
        </div>

        {/* Right Action Icons & Badges */}
        <div className="flex items-center gap-2">
          {/* n8n Live Status indicator */}
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#181c24] border border-slate-700/60 shadow-inner">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#4edea3] opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[#4edea3]"></span>
            </span>
            <span className="font-mono text-[10px] text-[#4edea3] font-semibold">
              n8n Live
            </span>
          </div>

          {/* Device Frame Viewport Toggle button (Phone view vs Desktop) */}
          <button
            onClick={onToggleDeviceFrame}
            title={isMobileDeviceFrame ? 'Modo móvil activo (Haz clic para expandir vista)' : 'Modo expandido (Haz clic para marco móvil)'}
            className={`min-h-[38px] px-2.5 rounded-xl border flex items-center gap-1 text-xs transition-all ${
              isMobileDeviceFrame
                ? 'bg-emerald-500/15 text-[#4edea3] border-emerald-500/30 shadow-glow-emerald'
                : 'bg-[#1c2028] text-slate-300 border-white/5 hover:text-white'
            }`}
          >
            <span className="material-symbols-outlined text-[18px]">
              {isMobileDeviceFrame ? 'phone_iphone' : 'desktop_windows'}
            </span>
            <span className="hidden sm:inline font-mono text-[10px]">
              {isMobileDeviceFrame ? 'Vista Móvil' : 'Vista Full'}
            </span>
          </button>

          {/* Quick Publish 1-Tap Trigger */}
          <button
            onClick={onOpenQuickPublish}
            aria-label="Publicación Flash"
            className="min-h-[38px] px-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-black font-display font-bold text-xs flex items-center gap-1.5 shadow-md shadow-emerald-500/20 active:scale-95 transition-all"
          >
            <span className="material-symbols-outlined text-[16px]">bolt</span>
            <span className="hidden sm:inline">Flash</span>
          </button>

          {/* Avatar Profile */}
          <button
            onClick={() => onChangeView('hub-central')}
            className="w-8 h-8 rounded-full bg-gradient-to-tr from-emerald-400 to-[#10b981] flex items-center justify-center text-[#003824] font-bold text-xs shadow-md border border-white/10"
            title="Abrir Menú Central del Ecosistema"
          >
            DP
          </button>
        </div>
      </div>
    </header>
  );
};
