import { BrandProfile, FxFilter, Pillar, CalendarPost, DailyMission } from './types';

export const BRANDS: BrandProfile[] = [
  {
    id: 'dulce-placer',
    name: 'Panadería Dulce Placer',
    tagline: 'Sube foto de producto y programa IG, Reels & TikTok',
    category: 'Pastelería & Café Artesanal',
    badge: 'Growth 360',
    icon: '🥐',
    whatsappEnabled: true,
    activeStrategy: 'Trimestre Estratégico 2025'
  },
  {
    id: 'andrea-brand',
    name: 'Andrea Influencer',
    tagline: 'Potenciación de marca y guiones de stories en automático',
    category: 'Lifestyle & Gourmet Growth',
    badge: 'Personal Brand',
    icon: '✨',
    whatsappEnabled: true,
    activeStrategy: 'Escala Creador 10X'
  }
];

export const FX_FILTERS: FxFilter[] = [
  {
    id: 'cinematic-gold',
    name: 'Cinematic Gold',
    description: 'Cálido • San Valentín',
    cssClass: 'fx-cinematic-gold',
    icon: '✨',
    previewUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDJhakE68pKE_pciBtGqvS0YoMxji7Nh77WYaT3iSCtjvJd3maAw3TUY8fMCgI9f-HXb3h-1pOC25BLss_WqoIPDlvjBYJQFXuBy0wu_S8nPl_NQuQD6g0jARO4SRLRsEZighCOEZhj4tEO-XfToW_8rX7dL0REfCxW4AFhtXcpJWga1Z9PeCdSbHGhOyQLbfzZQgh0-sQH4NSsz-i0oEpugkPnSUPlHNMXkeidpjgmIXupZxlFKGf1LA'
  },
  {
    id: 'cyber-glow',
    name: 'Cyber Neon',
    description: 'Cyber & TikTok Punch',
    cssClass: 'fx-cyber-glow',
    icon: '⚡',
    previewUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD_DVErO28NlshY12A6mHVX92H_mMQetxl77y0Vk5qn90lGSPk-vfENg7LZbrSVZhSua8qeP5uiSRcBvWwd1rU0doCQNtvzAikeSlrCBNR6V-gVo3tK1OVQmzpoYeJNWVh6dzpJ-a-bG_p6LVZD5vQ8wA85zDq3qyyRLAz-YHY1q9DaOJCTCtlAEFO3HMXV98Yl8b1QxDuyh0QYeVG7EFpBrN3V_nm-FHqUG22uRflWY99i4Z-GHGRWLw'
  },
  {
    id: 'bokeh-calido',
    name: 'Bokeh Cálido',
    description: 'Romántico & Gourmet',
    cssClass: 'fx-bokeh-calido',
    icon: '💖',
    previewUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBTXcG2iulD6ilU9Kxwf7herhHpSuEdCG8t0wFqEueO1ymxuOhV0y_974m3p-b3nqLQ9QBnwvrYSVZ26E6QS2NL8M28MZ8ZzxusPkfnjvVD7eN8Zoz1XO-1ZdhC_mMxTFBtOE1XtmAZPCMTNoUTMzx9eCOjV-AyH7FeqwlCV-tRMF8ISmoLTXEW5WJYGUrSO0G9EEvHcIPVUdhC5WRGayyJB9GqbD5ZejKArbKOnD6rxfpS5yPl7vr6eA'
  },
  {
    id: 'retro-vhs',
    name: 'Retro VHS',
    description: 'Grano Vintage y Nostalgia',
    cssClass: 'fx-retro-vhs',
    icon: '📼',
    previewUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDIKKpxF_91bVbX1TZ3YHd4M6MUPfF7bxmwSEnZvRHIC58f7XUT4jmzrQcZG4xXjili1lJnmJ6os-nNU2P94vRbCqIm__ZZKK90eNuNiYCPu_TedKN1XAACq4JRIrdtbTqBk-BRiL2tVv-ge0yWPndrL-egL2ZVBO0exAd1Xfk9VvNyH4J33oaVq9E6VmhUVkWzcTVDeBIADiY8d-kjN8q34WAo8USLoPRFZ2U-4goQutFFiEc32mbA6g'
  },
  {
    id: 'duotone-warm',
    name: 'Duotone Warm',
    description: 'Contraste Cálido Dorado',
    cssClass: 'fx-duotone-warm',
    icon: '🎨',
    previewUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAaNe3ov-wUXZ7exKOw6CqoZNC-3LyUh0AFKC1tVhC6x6Nxbqz3ZskJir21GdiDUTAG0U74t8Tzyfy1nowUnNQR5M3SF-a3SUCwkHcQIuZqoUeByl_e0RGmeE0lpzwH4ulecBRECMPjknL_I5g7G6rU6Rn4fvLwpQ2gBtky3zc53mudlzv42Jah-KDwyDtONF72nM91Gjf5Fnnt29blK4_foQIRA_OTBAhh9F6DtVzkciFP5_bAm89VDA'
  }
];

export const PILARES_ESTRATEGICOS: Pillar[] = [
  {
    id: 1,
    title: '1. Presencia de Marca',
    subtitle: 'Brand Authority & Estética Visual',
    status: 'Activo',
    statusColor: 'primary',
    badge: 'Reels 4K',
    description: 'Enfoque en Reels de masa madre artesanal, estética cuidada con tipografía de autor y ritmo hipnótico ASMR.',
    kpiLabel: 'KPI Meta:',
    kpiValue: '+45K',
    kpiDetail: 'reproducciones (78% completado)',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCDZ0ZZUfEscRF9tyvk0YrBQbuhs-tLG8RuwycXGyW6JQvVCkw3SaxJt4JAJxkWcMd2UXY_EUv46FWAubfJn-wp3GBE4rtU3pwhRxIS3hwZHiOHnjZ4uBdYE3Iv7MVxmc8lIBR9dTfRMDvYvlMp7NBciAfTJGdMnB28satEcUIiT1Ne9RTtL4oJ94WxU8l7XPFG_rWZ1OCrIDKwZVEihDlwNI6m5Nx8vALvYv8eEHL3jN9boDz2jL_zNA',
    tag: '4 piezas programadas'
  },
  {
    id: 2,
    title: '2. Aumento de Interacción',
    subtitle: 'Engagement, Retención & Viralidad',
    status: 'Optimizado IA',
    statusColor: 'secondary',
    badge: 'TikTok Hooks',
    description: 'Debates culinarios diarios ("¿Brioche dulce o salado?"), sticker interactivo en Stories y ganchos de 3 segundos en TikTok.',
    kpiLabel: 'KPI Meta:',
    kpiValue: '8.4%',
    kpiDetail: '↑ 9.1% actual',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCu2uuQ4a5WTAFqhQd50RyDoynDz9G2KpJXsrcL-tSe8P657WlitRvkqv0tJT4kZMbHb7-vC-Mg2pm90FbIu-l2_o1lg-8KwvwaRM0yzihtbQkoiNL_k8cNXfPX3j9jOxSLFILn6sSZBmGmYfIN_QIt7_TupAKr78Sav2zhk77Zc1nhSm-mVvKnBE6bEVGOr-QnX-jue35RA4r4Ue0zz9nLILDxQTygbRxFT_RukNrAdNHMy5PVf7-urg',
    tag: 'Encuestas de Recetas'
  },
  {
    id: 3,
    title: '3. Crecimiento de Comunidad',
    subtitle: 'Retención, Club VIP & Fidelidad Local',
    status: 'WhatsApp Activo',
    statusColor: 'tertiary',
    badge: 'Club VIP',
    description: 'Club de degustación exclusivo para clientes VIP de Panadería Dulce Placer, catas privadas de masa madre y canal de difusión vecinal.',
    kpiLabel: 'KPI Meta:',
    kpiValue: '+1,200',
    kpiDetail: 'miembros leales (64% logrado)',
    tag: 'Canal exclusivo con 640 miembros activos'
  },
  {
    id: 4,
    title: '4. Conversión y Ventas',
    subtitle: 'High-Intent Funnel & Escasez Flash',
    status: 'n8n Flow ON',
    statusColor: 'emerald',
    badge: 'HOY 18:00',
    description: 'Disparador automatizado por WhatsApp API + webhook de pedidos urgentes hacia cocina.',
    kpiLabel: 'KPI Meta:',
    kpiValue: '$3,450 USD',
    kpiDetail: '($2,180 atribuido a n8n)',
    tag: 'Combo Desayuno Hojaldre 2x1'
  }
];

export const CALENDAR_POSTS: CalendarPost[] = [
  {
    id: 'post-1',
    dayLabel: 'Hoy · Lunes',
    pillarCategory: 'BOFU',
    pillarLabel: 'Conversión (BOFU)',
    title: 'Combo 2x1 Hojaldre San Valentín',
    description: 'Disparador de escasez por tiempo limitado directo a canal WhatsApp VIP con checkout directo.',
    statusText: 'Listo para n8n',
    time: '19:30 hrs',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBDqXN59RF2YEV117nV94i8KynwtMCczfvNT5r8VeQo3wQrmkJjk0jzpOlRNObOp2n3Y6ppDD_NRmV0s6cSl50R7_LA3qgyZIAblxu8ZfVkb-HCr5kyWvzUTMs63B_jpg8paTbZyg93J1RzNArKirSUJJInBhsx01JBYDzaeUT7lS2ldclGiIr9YzJfO2eonVFddB1_sn1-YksjL3gpH9NX5QTj3tXiGDN_lzhdsZkF-XKDK4G_C7yGcQ',
    ratioBadge: '9:16',
    channels: ['whatsapp', 'instagram'],
    actionLabel: 'Publicar Ahora'
  },
  {
    id: 'post-2',
    dayLabel: 'Mañana · Martes',
    pillarCategory: 'MOFU',
    pillarLabel: 'Interacción (MOFU)',
    title: 'Encuesta: ¿Croissant clásico o con Nutella?',
    description: 'Encuesta de elección rápida para nutrir base de datos de preferencias de horneado matutino.',
    statusText: 'Programado auto',
    time: '08:15 hrs',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDytgBaVa8Dzuya8iIr-qrZ-j_zndtVOCih_prmlzZtLJlQC8FyPOn3tm2n5jJWyfnfgAjS2cIv7JvqWZflLxifIjfZT12Z0WbRMOqUI4Pb-yeGmh626JP3sU0QV8ikMWh82GVgPG22YPyUbsiqaoTBZWL1k7FXZnjdC74rXGaLOewnGkKYnk_3nviUVjoSiXmTcUjkMkGgTtDJ9zY3wjyQJcxxmN4-APieyE0d9ll6MDfbmX7JIpW93w',
    ratioBadge: 'STICKER',
    channels: ['instagram', 'tiktok']
  },
  {
    id: 'post-3',
    dayLabel: 'Jueves · 16:00',
    pillarCategory: 'TOFU',
    pillarLabel: 'Marca (TOFU)',
    title: 'Detrás de escena: Masa madre 24h',
    description: 'Pieza cinemática de alta retención. Explicación del proceso digestivo y valor artesanal.',
    statusText: 'Render IA en proceso (78%)',
    time: 'Luma 2.0',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAKY8nzVOInWXRuKjQ1ikqmS5psEDRsv3F4Mqi0XfSfAx2AHdT0pT89S-2o2qTC7tPnyw8nPPGGeyZyip520uhTRtHz6I8IGWfOIoadtgG8uuHTRhbVAaPwH8H0_6V4DiMET3rvtXm8w-MoWlDRdafW7IiD5KiKyE4XdM2zeDiUi4UkPBG1n4lWKx_z0j3qwe8tr4c10Gu1IdRqeLnPhOld1IGgHu_VpgnnxK5eCIos28V8O-bNFhDUpA',
    ratioBadge: '4K AI',
    channels: ['instagram', 'youtube']
  },
  {
    id: 'post-4',
    dayLabel: 'Sábado · 10:00',
    pillarCategory: 'Comunidad',
    pillarLabel: 'Comunidad VIP',
    title: 'Club del Pan Secreto: Cupón VIP',
    description: 'Mensaje de lealtad con pase exclusivo a la hornada secreta de focaccia con romero.',
    statusText: 'Borrador listo',
    time: 'Aprobar n8n',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC_iMLuwD5j5zbyQ6w19g3tu5vSLwo7YTYBv4d-wy-urOtp9awa045lre1jXOpb9yPiBDmKT5UUDVPzmPgla03jysvAw7gkI3WoUPLOQAge81x6wCH9yIw5cBvIVnakYZ1VZtK2kiuLC069L6nT068fO9fDgsGvYL7isQghGNb8D4XLvyWsOX_1csX_fAeumStlDSefqmh7K6qsSeyKrKkuFFPkVQUTBRv2f7ln63TdN0PqYiqlq3yScw',
    ratioBadge: 'VIP',
    channels: ['whatsapp']
  }
];

export const DAILY_MISSIONS: DailyMission[] = [
  {
    id: 'm-1',
    title: 'Publicar Reel ASMR Crujiente',
    badge: '+25K Vistas Est.',
    badgeColor: 'emerald',
    description: 'Captura audio cercano del primer corte del hojaldre recién horneado a las 8:00 AM.',
    hook: '"Escucha esto si tienes un día difícil..."',
    actionText: 'Guión IA',
    completed: true
  },
  {
    id: 'm-2',
    title: 'Lanzar Encuesta: "Sabor de la Semana"',
    badge: 'Retención 89%',
    badgeColor: 'fuchsia',
    description: 'Story con sticker de votación: Pistacho Glaseado vs. Maracuyá Silvestre.',
    actionText: 'Publicar',
    completed: false
  },
  {
    id: 'm-3',
    title: 'Broadcast VIP: Código Secreto Desayuno',
    badge: '98% Open Rate',
    badgeColor: 'amber',
    description: 'Enviar promoción relámpago con cupón exclusivo para los 640 miembros de WhatsApp.',
    actionText: 'Disparar n8n',
    completed: false
  }
];

export const HUB_MODULES = [
  {
    id: 'estrategia-integral',
    title: 'Marketing Studio 360 - Estrategia Integral',
    category: 'estrategia',
    badge: 'ESTRATEGIA 360',
    statusBadge: 'Q1 Activa',
    description: 'Gestión de los 4 pilares fundamentales (Presencia de Marca, Interacción, Comunidad y Conversión). Incluye balance de enfoque Q1 y sugerencias de Copilot en vivo.',
    tags: ['4 Pilares Activos', 'Distribución Omnicanal', 'Sprint IA'],
    targetScreen: 'estrategia' as const
  },
  {
    id: 'parrilla-embudo',
    title: 'Marketing Studio 360 - Parrilla y Embudo 360',
    category: 'estrategia',
    badge: 'OPERACIONES & PIPELINE',
    statusBadge: 'Sync n8n: 4m',
    description: 'Control de embudo de contenido (TOFU, MOFU, BOFU), parrilla de publicación sincronizada con automatización n8n y auditoría de coherencia de marca en tiempo real (98% OK).',
    tags: ['Embudo Multicanal', 'Disparador Flash 1-Tap', 'Brand Audit LLM'],
    targetScreen: 'calendario' as const
  },
  {
    id: 'experiencia-guiada',
    title: 'Marketing Studio 360 - Experiencia Guiada',
    category: 'estrategia',
    badge: 'WORKFLOW GUIADO',
    statusBadge: 'Paso a Paso',
    description: 'Asistente estructurado paso a paso para la definición estratégica de objetivos, elección de arquetipos de contenido y calendarización asistida por directrices inteligentes.',
    tags: ['Setup Asistido', 'Templates Estratégicos'],
    targetScreen: 'asistente-4pasos' as const
  },
  {
    id: 'canvas-chat-ia',
    title: 'Marketing Studio 360 - Canvas & Chat IA',
    category: 'creativo',
    badge: 'LIVE CANVAS PRO',
    statusBadge: 'Latencia: 180ms',
    description: 'Entorno insignia de creación modular: lienzo interactivo con Split A/B, edición conversacional mediante Studio AI Copilot, carrusel de filtros FX y tipografía editable.',
    tags: ['Formatos 9:16, 1:1, 4:5', 'Prompt por Voz & Deshacer', 'Aprobación Directa'],
    targetScreen: 'studio-canvas' as const
  },
  {
    id: 'edicion-visual-fx',
    title: 'Marketing Studio 360 - Edición Visual & FX',
    category: 'creativo',
    badge: 'FX & TIPOGRAFÍA',
    statusBadge: '4 Filtros Pro',
    description: 'Módulo centrado en efectos visuales de alta conversión: catálogo táctil de presets (Cinematic Gold, Cyber Glow, Retro VHS, Duotone Warm) y selector avanzado de tipografía.',
    tags: ['Catálogo FX Visual', 'Render Dinámico', 'Control de Fuentes'],
    targetScreen: 'studio-canvas' as const
  },
  {
    id: 'estudio-modular',
    title: 'Marketing Studio 360 - Estudio Modular & Chat IA',
    category: 'creativo',
    badge: 'FAST ENGINE',
    statusBadge: 'Claude 3.5',
    description: 'Flujo ágil de edición con Copilot contextual, panel de efectos de iluminación (Bokeh Cálido, Glitch Sutil, Vintage Film) y disparador para publicar a canales con 1 toque.',
    tags: ['Variar Copy con IA', 'Auto-centrado inteligente', 'Destino Instagram & WA'],
    targetScreen: 'studio-canvas' as const
  },
  {
    id: 'flujo-fast-track',
    title: 'Marketing Studio 360 - Flujo Fast-Track & Chat IA',
    category: 'creativo',
    badge: 'FAST-TRACK 2-STEPS',
    statusBadge: '⚡ Express n8n',
    description: 'Diseñado para edición ultra veloz: chat superior prominente con diálogo conversacional, mini-canvas con switch Antes vs Después (IA), y acciones instantáneas de 1 toque.',
    tags: ['Mini-Canvas Antes/Después', 'Chat Prioritario', 'Botón Continuar Directo'],
    targetScreen: 'asistente-4pasos' as const
  },
  {
    id: 'copilot-canvas-modular',
    title: 'Marketing Studio 360 - Copilot IA & Canvas Modular',
    category: 'creativo',
    badge: 'CANVAS & COPILOT',
    statusBadge: 'Online',
    description: 'Herramienta modular balanceada que reúne el canvas visual adaptable a 3 relaciones de aspecto, asistente creativo contextual y presets de alto impacto.',
    tags: ['1:1 Feed / 9:16 Story', 'Aprobar vía n8n', 'Render Ultra-HD'],
    targetScreen: 'studio-canvas' as const
  },
  {
    id: 'crecimiento-escalabilidad',
    title: 'Marketing Studio 360 - Crecimiento Rápido & Escalabilidad Creador',
    category: 'growth',
    badge: 'CRECIMIENTO EXPONENCIAL',
    statusBadge: '🚀 Escalar 10x',
    description: 'Visualización de progresión de niveles (Nivel 3: Creador Emergente 78k hacia Nivel 4 Autor), métricas de retención en primeros 3s (68%), y tácticas de ganchos sensoriales y ASMR.',
    tags: ['480k Vistas Acumuladas', '$4,850 USD Proyectados', 'Horas Pico Inteligentes'],
    targetScreen: 'roadmap' as const
  },
  {
    id: 'canvas-viral-growth',
    title: 'Marketing Studio 360 - Canvas Viral & Copilot Growth',
    category: 'growth',
    badge: 'VIRALIDAD 94/100',
    statusBadge: 'Top 3% Nicho',
    description: 'Simulador de piezas virales para formato 9:16 con analizador de retención de gancho inicial, disparador de comentarios con palabras clave ("Comenta CROISSANT") y Copilot algorítmico.',
    tags: ['Score Viral Predictivo', 'Zoom Dinámico & ASMR', 'Multi-Distribución'],
    targetScreen: 'roadmap' as const
  },
  {
    id: 'roadmap-influencer-monetizacion',
    title: 'Marketing Studio 360 - Roadmap Influencer & Monetización',
    category: 'growth',
    badge: 'MONETIZACIÓN & COMUNIDAD',
    statusBadge: 'Fase 2 de 4 (68%)',
    description: 'Plan estructurado para escalar de creador novel a influencer rentable: misiones diarias gamificadas para multiplicar reproducciones y aceleración del Club VIP de WhatsApp (1,840 clientes).',
    tags: ['Misiones con Guión IA', 'Club WhatsApp +42 hoy', 'Canal 5.9k fans (98% open)'],
    targetScreen: 'roadmap' as const
  },
  {
    id: 'mobile-redesign',
    title: 'Marketing Studio 360 - Mobile Redesign',
    category: 'growth',
    badge: 'CORE UI / UX',
    statusBadge: 'Layout v2',
    description: 'Arquitectura de interfaz depurada y optimizada para pantallas táctiles, condensando formularios densos en vistas compactas sin scroll innecesario.',
    tags: ['Estructura Compacta', 'Modo Cero Scroll', 'Mobile First'],
    targetScreen: 'estrategia' as const
  }
];
