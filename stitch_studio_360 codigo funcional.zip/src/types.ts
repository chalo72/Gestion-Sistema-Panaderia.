export type ScreenView = 
  | 'estrategia' 
  | 'studio-canvas' 
  | 'calendario' 
  | 'roadmap' 
  | 'asistente-4pasos' 
  | 'hub-central';

export interface BrandProfile {
  id: string;
  name: string;
  tagline: string;
  category: string;
  badge: string;
  icon: string;
  whatsappEnabled: boolean;
  activeStrategy: string;
}

export interface FxFilter {
  id: string;
  name: string;
  description: string;
  cssClass: string;
  icon: string;
  previewUrl: string;
}

export interface Pillar {
  id: number;
  title: string;
  subtitle: string;
  status: string;
  statusColor: string;
  badge: string;
  description: string;
  kpiLabel: string;
  kpiValue: string;
  kpiDetail: string;
  image?: string;
  imageAlt?: string;
  tag?: string;
}

export interface CalendarPost {
  id: string;
  dayLabel: string;
  pillarCategory: 'BOFU' | 'MOFU' | 'TOFU' | 'Comunidad';
  pillarLabel: string;
  title: string;
  description: string;
  statusText: string;
  time: string;
  imageUrl: string;
  ratioBadge: string;
  channels: ('whatsapp' | 'instagram' | 'tiktok' | 'youtube')[];
  actionLabel?: string;
}

export interface DailyMission {
  id: string;
  title: string;
  badge: string;
  badgeColor: string;
  description: string;
  hook?: string;
  actionText: string;
  completed: boolean;
}
