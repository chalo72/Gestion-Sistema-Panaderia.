import { useState, useEffect } from 'react';
import { ScreenView, BrandProfile } from './types';
import { BRANDS } from './data';
import { TopHeader } from './components/TopHeader';
import { BottomNav } from './components/BottomNav';
import { EstrategiaView } from './components/EstrategiaView';
import { StudioCanvasView } from './components/StudioCanvasView';
import { CalendarioParrillaView } from './components/CalendarioParrillaView';
import { RoadmapGrowthView } from './components/RoadmapGrowthView';
import { Asistente4PasosView } from './components/Asistente4PasosView';
import { HubCentralView } from './components/HubCentralView';
import { ToastNotification } from './components/ToastNotification';
import { QuickPublishModal } from './components/QuickPublishModal';

export function App() {
  const [activeBrand, setActiveBrand] = useState<BrandProfile>(BRANDS[0]);
  const [currentView, setCurrentView] = useState<ScreenView>('estrategia');
  const [isMobileDeviceFrame, setIsMobileDeviceFrame] = useState<boolean>(false);
  const [toast, setToast] = useState<{ message: string | null; type: 'success' | 'info' | 'ai' }>({
    message: null,
    type: 'success'
  });
  const [isQuickPublishOpen, setIsQuickPublishOpen] = useState<boolean>(false);

  // Auto-scroll to top on view change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentView]);

  const showToast = (message: string, type: 'success' | 'info' | 'ai' = 'success') => {
    setToast({ message, type });
    // auto dismiss after 3.5s
    setTimeout(() => {
      setToast((prev) => (prev.message === message ? { message: null, type: 'success' } : prev));
    }, 3500);
  };

  return (
    <div className="min-h-screen bg-[#080b11] text-[#dfe2ee] flex flex-col items-center selection:bg-emerald-500/30 selection:text-[#4edea3] font-sans antialiased">
      {/* Top Application Header */}
      <TopHeader
        activeBrand={activeBrand}
        brands={BRANDS}
        onSelectBrand={(brand) => setActiveBrand(brand)}
        currentView={currentView}
        onChangeView={(view) => setCurrentView(view)}
        onOpenQuickPublish={() => setIsQuickPublishOpen(true)}
        isMobileDeviceFrame={isMobileDeviceFrame}
        onToggleDeviceFrame={() => setIsMobileDeviceFrame(!isMobileDeviceFrame)}
        onShowToast={(msg) => showToast(msg, 'info')}
      />

      {/* Main Content Area: Responsive Frame (Mobile Frame vs Expanded Full Layout) */}
      <main
        className={`w-full transition-all duration-300 px-3 pt-3 sm:px-4 ${
          isMobileDeviceFrame
            ? 'max-w-md my-4 rounded-[36px] border border-slate-700/60 bg-[#0f131c] shadow-[0_20px_60px_rgba(0,0,0,0.8)] ring-1 ring-white/10 overflow-hidden'
            : 'max-w-3xl'
        }`}
      >
        {/* Active Screen View Router */}
        {currentView === 'estrategia' && (
          <EstrategiaView
            activeBrand={activeBrand}
            onChangeView={(view) => setCurrentView(view)}
            onShowToast={(msg) => showToast(msg, 'success')}
          />
        )}

        {currentView === 'studio-canvas' && (
          <StudioCanvasView
            activeBrand={activeBrand}
            onShowToast={(msg) => showToast(msg, 'ai')}
            onOpenQuickPublish={() => setIsQuickPublishOpen(true)}
          />
        )}

        {currentView === 'calendario' && (
          <CalendarioParrillaView
            activeBrand={activeBrand}
            onChangeView={(view) => setCurrentView(view)}
            onShowToast={(msg) => showToast(msg, 'success')}
          />
        )}

        {currentView === 'roadmap' && (
          <RoadmapGrowthView
            activeBrand={activeBrand}
            onChangeView={(view) => setCurrentView(view)}
            onShowToast={(msg) => showToast(msg, 'success')}
          />
        )}

        {currentView === 'asistente-4pasos' && (
          <Asistente4PasosView
            activeBrand={activeBrand}
            onChangeView={(view) => setCurrentView(view)}
            onShowToast={(msg) => showToast(msg, 'success')}
          />
        )}

        {currentView === 'hub-central' && (
          <HubCentralView
            onChangeView={(view) => setCurrentView(view)}
            onShowToast={(msg) => showToast(msg, 'info')}
            onOpenQuickPublish={() => setIsQuickPublishOpen(true)}
          />
        )}
      </main>

      {/* Persistent Bottom Navigation */}
      <BottomNav currentView={currentView} onChangeView={(view) => setCurrentView(view)} />

      {/* Floating Toast Notification */}
      <ToastNotification
        message={toast.message}
        type={toast.type}
        onClose={() => setToast({ message: null, type: 'success' })}
      />

      {/* 1-Tap Flash Publish Modal */}
      <QuickPublishModal
        isOpen={isQuickPublishOpen}
        onClose={() => setIsQuickPublishOpen(false)}
        onSuccess={(msg) => showToast(msg, 'success')}
        activeBrandName={activeBrand.name}
      />
    </div>
  );
}

export default App;
