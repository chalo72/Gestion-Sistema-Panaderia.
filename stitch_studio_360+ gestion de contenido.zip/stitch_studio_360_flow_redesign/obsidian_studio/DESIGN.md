---
name: Obsidian Studio
colors:
  surface: '#0f131c'
  surface-dim: '#0f131c'
  surface-bright: '#353942'
  surface-container-lowest: '#0a0e16'
  surface-container-low: '#181c24'
  surface-container: '#1c2028'
  surface-container-high: '#262a33'
  surface-container-highest: '#31353e'
  on-surface: '#dfe2ee'
  on-surface-variant: '#bbcabf'
  inverse-surface: '#dfe2ee'
  inverse-on-surface: '#2c3039'
  outline: '#86948a'
  outline-variant: '#3c4a42'
  surface-tint: '#4edea3'
  primary: '#4edea3'
  on-primary: '#003824'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#006c49'
  secondary: '#d0bcff'
  on-secondary: '#3c0091'
  secondary-container: '#571bc1'
  on-secondary-container: '#c4abff'
  tertiary: '#4cd7f6'
  on-tertiary: '#003640'
  tertiary-container: '#00b2d0'
  on-tertiary-container: '#003f4b'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#e9ddff'
  secondary-fixed-dim: '#d0bcff'
  on-secondary-fixed: '#23005c'
  on-secondary-fixed-variant: '#5516be'
  tertiary-fixed: '#acedff'
  tertiary-fixed-dim: '#4cd7f6'
  on-tertiary-fixed: '#001f26'
  on-tertiary-fixed-variant: '#004e5c'
  background: '#0f131c'
  on-background: '#dfe2ee'
  surface-variant: '#31353e'
typography:
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  title-md:
    fontFamily: Space Grotesk
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 22px
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 9px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.5rem
  margin: 1.5rem
  margin-mobile: 0.75rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style

This design system establishes a high-performance creative cockpit tailored for modern marketing directors, visual artists, and campaign leads working across desktop and touch interfaces. The environment balances the austere discipline of pro-grade audio/video DAWs with the fluid tactility of contemporary creative tools.

### Design Movement & Aesthetic
The aesthetic unites **Dark Precision Modernism** with **Engineered Glassmorphism**:
- **Deep Obsidian Substrates**: Light-absorbent foundations eliminate visual noise and allow content layers and key creative artifacts to stand out as the primary visual focus.
- **Controlled Luminescence**: Emerald neon serves as the engine state and primary action accent, grounded by deep electric violet and cyan auxiliary channels for generative AI operations and multi-track marketing layers.
- **Glassmorphic Spatial Hierarchy**: Translucent overlays with calibrated backdrops keep context visible underneath floating inspectors, floating action bars, and modal generation sheets without breaking user immersion.
- **Tactile Density**: High-density, micro-tooled components with precise touch/click targets engineered for rapid campaign prototyping, multi-format previews, and conversational asset transformations.

## Colors

The palette leverages high-contrast chromatic accents against dark, blue-shifted obsidian neutral layers to support extended studio workflows without eye fatigue.

### Color Roles & Semantics
- **Primary (`#10B981` Emerald Neon)**: Applied to execution points, generation triggers, active timeline nodes, published statuses, and high-confidence metrics. Emits a calibrated ambient glow (`rgba(16, 185, 129, 0.25)`) when active or rendering.
- **Secondary (`#8B5CF6` Electric Violet)**: Reserved for contextual AI actions, prompt states, multi-asset synthesis, and conversational generative filters.
- **Tertiary (`#06B6D4` Electric Cyan)**: Used for responsive layout viewports, device bounding boxes, vector handles, typography kerning indicators, and real-time preview guides.
- **Neutral Core (`#0B0F17` to `#1E293B`)**:
  - `Canvas Base`: `#070A0F` (True dark foundation behind infinite canvas).
  - `Surface Void`: `#0B0F17` (Global shell, base sidebars, collapsed docks).
  - `Surface Low`: `#131A26` (Inspector panels, docked card containers, drawer bodies).
  - `Surface Glass`: `rgba(19, 26, 38, 0.72)` (Floating toolbars, context menus, chat HUD).
  - `Surface Highlight`: `rgba(255, 255, 255, 0.05)` (Subtle surface light capture on top edges).
  - `Border Subtle`: `rgba(255, 255, 255, 0.08)` (Structural structural panel divides).
  - `Border Focus`: `rgba(16, 185, 129, 0.60)` (Active input and node focus).

### Functional Gradients
- **AI Synthesis Gradient**: Linear 135deg from `#8B5CF6` through `#06B6D4` to `#10B981`, used sparingly for prompt submissions, magic wand tools, and active model generation progress bars.

## Typography

The typographic hierarchy establishes distinct voices for studio orchestration:
1. **Space Grotesk (Headlines & Modules)**: Delivers a geometric, forward-leaning character for viewport titles, campaign stage names, and inspector section groupings.
2. **Inter (Interface & Conversation Body)**: Highly legible at compact sizes, handling AI conversational streams, user notes, and property label documentation without glyph ambiguity.
3. **JetBrains Mono (Telemetry, Parameters & Badges)**: Communicates technical fidelity for coordinates (X/Y/W/H), RGB/HEX hex values, font size steppers, timeline timestamps, and state pills.

All text sizes below 12px must use medium to semi-bold weights with uppercase tracking to maintain legibility on blurred glass layers.

## Layout & Spacing

The spatial architecture supports an adaptive studio workstation that scales from compact single-column mobile views to multi-monitor desktop arrangements.

### Responsive Breakpoints & Viewport Behavior
- **Mobile (`< 768px`)**: Single-column viewport with edge-to-edge preview canvas. Top bar hosts project state and view switcher; bottom hosts a collapsible Contextual AI HUD and drawer-accessible properties. Floating tools collapse into a radial or bottom thumb bar.
- **Tablet (`768px - 1199px`)**: Dual-pane layout. The interactive canvas anchors the center, with a floating right inspector drawer (`320px`) and floating dock bar for tool selection.
- **Desktop (`>= 1200px`)**: Full triple-pane workspace. Fixed left asset rack (`260px`), central interactive infinite stage, right modular properties stack (`340px`), and docked conversational AI studio tray at the bottom viewport center (`max-w-3xl`).

### Layout Cadence
All spatial distances follow an exact 4px unit multiplier:
- Compact tool groupings, segmented control bars, and chip tracks use `space-xs` (4px) and `space-sm` (8px).
- Internal card padding and tool strip margins utilize `space-md` (12px).
- Module container separation and major drawer padding use `space-lg` (20px).
- Major panel separations and canvas outer limits use `space-xl` (32px).

## Elevation & Depth

Visual depth is achieved through layered frosted substrates, light-rimmed borders, and colored photon diffusion instead of standard drop shadows.

### Glassmorphic Levels
1. **L0 - Stage Floor (`#070A0F`)**: Infinite raw canvas with an optional sub-pixel grid pattern (`rgba(255, 255, 255, 0.03)` on 16px centers).
2. **L1 - Structural Docks (`#0B0F17`)**: Sidebars and persistent workspace frame. 100% opaque or `rgba(11, 15, 23, 0.85)` with `backdrop-filter: blur(16px)`. Border-right / border-left: `1px solid rgba(255, 255, 255, 0.06)`.
3. **L2 - Floating Toolbars & Cards (`rgba(19, 26, 38, 0.72)`)**: Floating manipulation bars, segmented controls, typography palettes. Styled with `backdrop-filter: blur(20px)`, top edge inset shadow `inset 0 1px 0 rgba(255, 255, 255, 0.12)`, and outer shadow `0 8px 32px -4px rgba(0, 0, 0, 0.6)`.
4. **L3 - AI Chat & Context HUD (`rgba(19, 26, 38, 0.88)`)**: Prominently layered above canvas content with dynamic glow halos:
   - Default: `0 12px 40px rgba(0, 0, 0, 0.75), 0 0 0 1px rgba(255, 255, 255, 0.08)`.
   - Active Generative Execution: `0 12px 48px rgba(0, 0, 0, 0.85), 0 0 24px rgba(139, 92, 246, 0.25), 0 0 0 1px rgba(139, 92, 246, 0.4)`.
5. **L4 - Overlays & Popovers**: Contextual menus, asset selectors, and modal preview sheets at `rgba(11, 15, 23, 0.94)` with `backdrop-filter: blur(28px)`.

## Shapes

The interface balances sharp technical precision with approachable organic touch points using a controlled curvature scale:

- **Base Radius (`rounded`, 8px)**: Inputs, segmented button segments, dropdown items, tool selectors, and slider thumbs.
- **Card & Inspector Radius (`rounded-lg`, 16px)**: Inspector sub-panels, preview cards, asset tiles, and floating tool strips.
- **Enclosure & Sheet Radius (`rounded-xl`, 24px)**: Generative chat console, viewport control islands, preview popovers, and bottom sheet containers on mobile devices.
- **Pill Geometry (`rounded-full`)**: Status indicators, category chips, tool mode switches, and action FABs.

## Components

### Buttons & Action Triggers
- **Primary Studio Action**: Background `#10B981`, foreground `#070A0F` (bold, readable contrast). Subtle box-shadow: `0 0 16px rgba(16, 185, 129, 0.35)`. Hover: `#34D399` with intensified neon halo.
- **AI Magic Action**: Background in a directional gradient (`#8B5CF6` to `#06B6D4`), foreground `#FFFFFF`. Pressed scale: `0.98`.
- **Ghost/Glass Action**: Background `rgba(255, 255, 255, 0.04)`, border `1px solid rgba(255, 255, 255, 0.08)`, text `#E2E8F0`. Hover brings background to `rgba(255, 255, 255, 0.08)` and border to `rgba(255, 255, 255, 0.16)`.
- **Micro Tool Buttons**: 32x32px square targets with 8px radius, holding centered monochrome SVG icons. Active state activates `#10B981` tint with a bottom dot indicator.

### Input Fields & Parameter Controls
- **Numeric Stepper Inputs**: Flat dark backgrounds (`#0B0F17`), inline monospace numbers, drag-to-scrub cursor interaction on labels (e.g., `X:`, `Y:`, `Tracking:`).
- **Text & Prompt Inputs**: Glass enclosure (`rgba(255, 255, 255, 0.03)`), inset border `rgba(255, 255, 255, 0.1)`. Focus state produces an emerald ring `0 0 0 1px #10B981` and ambient base flare.

### Conversational AI Creative Bar
- Anchored at bottom-center of the preview canvas.
- Features a prompt field with dynamic multi-modal pill attachments (e.g., `[Subject: Hero Image]`, `[Preset: Neon Noir]`, `[Aspect: 9:16]`).
- Includes one-touch quick filter suggestions directly above the input: pills like *“Increase Contrast”*, *“Translate to Spanish”*, *“Add Glitch Effect”*, and *“Optimize for Story Ad”*.
- Provides real-time rendering feedback with an electric violet animated shimmer border along the top rim.

### Modular Preview Canvas
- Canvas supports zoom, infinite pan, and multi-format device frames (Story, Reel, Post, Banner, Billboard).
- Real-time overlay bounding boxes use cyan `#06B6D4` vector outlines with corner resize nodes and a floating rotational pip.
- Hovering over canvas elements reveals contextual mini-inspectors for typography adjustments (font weight, size, tracking) directly on top of the artboard.

### Cards & Asset Tiles
- **Media Asset Card**: 16px radius, dark glass substrate, edge highlight on hover. Thumbnail occupies full width with technical metadata tags (`MP4`, `PNG`, `1080x1920`) layered in `label-sm` monospace badges in the top corners.
- **Filter Preset Card**: Compact square format with split split-view visual previews; selecting a card transitions the border from neutral subtle to `#10B981` with an active check pip.

### Checkboxes, Toggles & Radios
- **Toggle Switches**: 40x22px track in `#131A26` with a 1px border. When toggled, track transitions to `#10B981` with a sliding white thumb and an emerald-tinted drop shadow.
- **Checkboxes**: 16x16px boxes with 4px radius. Checked state fills with `#10B981` and renders a `#070A0F` checkmark.